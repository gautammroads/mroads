
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.cosmos;

import java.util.Optional;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "telephoneNumber",
    "telephoneNumberExtn",
    "emergencyTelephoneNumber",
    "emergencyTelephoneNumberExtn",
    "FaxNumber",
    "email"
})
public class Communication {

    @JsonProperty("telephoneNumber")
    private String telephoneNumber;
    @JsonProperty("telephoneNumberExtn")
    private String telephoneNumberExtn;
    @JsonProperty("emergencyTelephoneNumber")
    private String emergencyTelephoneNumber;
    @JsonProperty("emergencyTelephoneNumberExtn")
    private String emergencyTelephoneNumberExtn;
    @JsonProperty("FaxNumber")
    private String faxNumber;
    @JsonProperty("email")
    private String email;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Communication() {
    }

    /**
     * 
     * @param telephoneNumberExtn
     * @param emergencyTelephoneNumberExtn
     * @param telephoneNumber
     * @param emergencyTelephoneNumber
     * @param faxNumber
     * @param email
     */
    public Communication(String telephoneNumber, String telephoneNumberExtn, String emergencyTelephoneNumber, String emergencyTelephoneNumberExtn, String faxNumber, String email) {
        super();
        this.telephoneNumber = telephoneNumber;
        this.telephoneNumberExtn = telephoneNumberExtn;
        this.emergencyTelephoneNumber = emergencyTelephoneNumber;
        this.emergencyTelephoneNumberExtn = emergencyTelephoneNumberExtn;
        this.faxNumber = faxNumber;
        this.email = email;
    }

    @JsonProperty("telephoneNumber")
    public Optional<String> getTelephoneNumber() {
        return Optional.ofNullable(telephoneNumber);
    }

    @JsonProperty("telephoneNumber")
    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    @JsonProperty("telephoneNumberExtn")
    public Optional<String> getTelephoneNumberExtn() {
        return Optional.ofNullable(telephoneNumberExtn);
    }

    @JsonProperty("telephoneNumberExtn")
    public void setTelephoneNumberExtn(String telephoneNumberExtn) {
        this.telephoneNumberExtn = telephoneNumberExtn;
    }

    @JsonProperty("emergencyTelephoneNumber")
    public Optional<String> getEmergencyTelephoneNumber() {
        return Optional.ofNullable(emergencyTelephoneNumber);
    }

    @JsonProperty("emergencyTelephoneNumber")
    public void setEmergencyTelephoneNumber(String emergencyTelephoneNumber) {
        this.emergencyTelephoneNumber = emergencyTelephoneNumber;
    }

    @JsonProperty("emergencyTelephoneNumberExtn")
    public Optional<String> getEmergencyTelephoneNumberExtn() {
        return Optional.ofNullable(emergencyTelephoneNumberExtn);
    }

    @JsonProperty("emergencyTelephoneNumberExtn")
    public void setEmergencyTelephoneNumberExtn(String emergencyTelephoneNumberExtn) {
        this.emergencyTelephoneNumberExtn = emergencyTelephoneNumberExtn;
    }

    @JsonProperty("FaxNumber")
    public Optional<String> getFaxNumber() {
        return Optional.ofNullable(faxNumber);
    }

    @JsonProperty("FaxNumber")
    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    @JsonProperty("email")
    public Optional<String> getEmail() {
        return Optional.ofNullable(email);
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Communication.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("telephoneNumber");
        sb.append('=');
        sb.append(((this.telephoneNumber == null)?"<null>":this.telephoneNumber));
        sb.append(',');
        sb.append("telephoneNumberExtn");
        sb.append('=');
        sb.append(((this.telephoneNumberExtn == null)?"<null>":this.telephoneNumberExtn));
        sb.append(',');
        sb.append("emergencyTelephoneNumber");
        sb.append('=');
        sb.append(((this.emergencyTelephoneNumber == null)?"<null>":this.emergencyTelephoneNumber));
        sb.append(',');
        sb.append("emergencyTelephoneNumberExtn");
        sb.append('=');
        sb.append(((this.emergencyTelephoneNumberExtn == null)?"<null>":this.emergencyTelephoneNumberExtn));
        sb.append(',');
        sb.append("faxNumber");
        sb.append('=');
        sb.append(((this.faxNumber == null)?"<null>":this.faxNumber));
        sb.append(',');
        sb.append("email");
        sb.append('=');
        sb.append(((this.email == null)?"<null>":this.email));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.telephoneNumberExtn == null)? 0 :this.telephoneNumberExtn.hashCode()));
        result = ((result* 31)+((this.emergencyTelephoneNumberExtn == null)? 0 :this.emergencyTelephoneNumberExtn.hashCode()));
        result = ((result* 31)+((this.telephoneNumber == null)? 0 :this.telephoneNumber.hashCode()));
        result = ((result* 31)+((this.emergencyTelephoneNumber == null)? 0 :this.emergencyTelephoneNumber.hashCode()));
        result = ((result* 31)+((this.faxNumber == null)? 0 :this.faxNumber.hashCode()));
        result = ((result* 31)+((this.email == null)? 0 :this.email.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Communication) == false) {
            return false;
        }
        Communication rhs = ((Communication) other);
        return (((((((this.telephoneNumberExtn == rhs.telephoneNumberExtn)||((this.telephoneNumberExtn!= null)&&this.telephoneNumberExtn.equals(rhs.telephoneNumberExtn)))&&((this.emergencyTelephoneNumberExtn == rhs.emergencyTelephoneNumberExtn)||((this.emergencyTelephoneNumberExtn!= null)&&this.emergencyTelephoneNumberExtn.equals(rhs.emergencyTelephoneNumberExtn))))&&((this.telephoneNumber == rhs.telephoneNumber)||((this.telephoneNumber!= null)&&this.telephoneNumber.equals(rhs.telephoneNumber))))&&((this.emergencyTelephoneNumber == rhs.emergencyTelephoneNumber)||((this.emergencyTelephoneNumber!= null)&&this.emergencyTelephoneNumber.equals(rhs.emergencyTelephoneNumber))))&&((this.faxNumber == rhs.faxNumber)||((this.faxNumber!= null)&&this.faxNumber.equals(rhs.faxNumber))))&&((this.email == rhs.email)||((this.email!= null)&&this.email.equals(rhs.email))));
    }

    public static class CommunicationBuilder<T extends Communication >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public CommunicationBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(Communication.CommunicationBuilder.class)) {
                this.instance = ((T) new Communication());
            }
        }

        @SuppressWarnings("unchecked")
        public CommunicationBuilder(String telephoneNumber, String telephoneNumberExtn, String emergencyTelephoneNumber, String emergencyTelephoneNumberExtn, String faxNumber, String email) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(Communication.CommunicationBuilder.class)) {
                this.instance = ((T) new Communication(telephoneNumber, telephoneNumberExtn, emergencyTelephoneNumber, emergencyTelephoneNumberExtn, faxNumber, email));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public Communication.CommunicationBuilder withTelephoneNumber(String telephoneNumber) {
            ((Communication) this.instance).telephoneNumber = telephoneNumber;
            return this;
        }

        public Communication.CommunicationBuilder withTelephoneNumberExtn(String telephoneNumberExtn) {
            ((Communication) this.instance).telephoneNumberExtn = telephoneNumberExtn;
            return this;
        }

        public Communication.CommunicationBuilder withEmergencyTelephoneNumber(String emergencyTelephoneNumber) {
            ((Communication) this.instance).emergencyTelephoneNumber = emergencyTelephoneNumber;
            return this;
        }

        public Communication.CommunicationBuilder withEmergencyTelephoneNumberExtn(String emergencyTelephoneNumberExtn) {
            ((Communication) this.instance).emergencyTelephoneNumberExtn = emergencyTelephoneNumberExtn;
            return this;
        }

        public Communication.CommunicationBuilder withFaxNumber(String faxNumber) {
            ((Communication) this.instance).faxNumber = faxNumber;
            return this;
        }

        public Communication.CommunicationBuilder withEmail(String email) {
            ((Communication) this.instance).email = email;
            return this;
        }

    }

}

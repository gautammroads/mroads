
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * retailPharmacyLocation
 * <p>
 * 
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "pharmacyId",
    "pharmacyName",
    "distanceFromSearchLocation",
    "pharmacyAddress",
    "pharmacyCommunication",
    "pharmacySchedule"
})
public class RetailPharmacyLocation {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("pharmacyId")
    @NotNull
    private String pharmacyId;
    @JsonProperty("pharmacyName")
    private String pharmacyName;
    @JsonProperty("distanceFromSearchLocation")
    private double distanceFromSearchLocation;
    /**
     * pharmacyAddress
     * <p>
     * 
     * 
     */
    @JsonProperty("pharmacyAddress")
    @Valid
    private PharmacyAddress pharmacyAddress;
    /**
     * pharmacyCommunication
     * <p>
     * 
     * 
     */
    @JsonProperty("pharmacyCommunication")
    @Valid
    private PharmacyCommunication pharmacyCommunication;
    @JsonProperty("pharmacySchedule")
    @Valid
    private List<OperatingHours> pharmacySchedule = new ArrayList<OperatingHours>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public RetailPharmacyLocation() {
    }

    /**
     * 
     * @param pharmacyId
     * @param pharmacyCommunication
     * @param pharmacyAddress
     * @param pharmacyName
     * @param distanceFromSearchLocation
     * @param pharmacySchedule
     */
    public RetailPharmacyLocation(String pharmacyId, String pharmacyName, double distanceFromSearchLocation, PharmacyAddress pharmacyAddress, PharmacyCommunication pharmacyCommunication, List<OperatingHours> pharmacySchedule) {
        super();
        this.pharmacyId = pharmacyId;
        this.pharmacyName = pharmacyName;
        this.distanceFromSearchLocation = distanceFromSearchLocation;
        this.pharmacyAddress = pharmacyAddress;
        this.pharmacyCommunication = pharmacyCommunication;
        this.pharmacySchedule = pharmacySchedule;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("pharmacyId")
    public String getPharmacyId() {
        return pharmacyId;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("pharmacyId")
    public void setPharmacyId(String pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    @JsonProperty("pharmacyName")
    public Optional<String> getPharmacyName() {
        return Optional.ofNullable(pharmacyName);
    }

    @JsonProperty("pharmacyName")
    public void setPharmacyName(String pharmacyName) {
        this.pharmacyName = pharmacyName;
    }

    @JsonProperty("distanceFromSearchLocation")
    public double getDistanceFromSearchLocation() {
        return distanceFromSearchLocation;
    }

    @JsonProperty("distanceFromSearchLocation")
    public void setDistanceFromSearchLocation(double distanceFromSearchLocation) {
        this.distanceFromSearchLocation = distanceFromSearchLocation;
    }

    /**
     * pharmacyAddress
     * <p>
     * 
     * 
     */
    @JsonProperty("pharmacyAddress")
    public Optional<PharmacyAddress> getPharmacyAddress() {
        return Optional.ofNullable(pharmacyAddress);
    }

    /**
     * pharmacyAddress
     * <p>
     * 
     * 
     */
    @JsonProperty("pharmacyAddress")
    public void setPharmacyAddress(PharmacyAddress pharmacyAddress) {
        this.pharmacyAddress = pharmacyAddress;
    }

    /**
     * pharmacyCommunication
     * <p>
     * 
     * 
     */
    @JsonProperty("pharmacyCommunication")
    public Optional<PharmacyCommunication> getPharmacyCommunication() {
        return Optional.ofNullable(pharmacyCommunication);
    }

    /**
     * pharmacyCommunication
     * <p>
     * 
     * 
     */
    @JsonProperty("pharmacyCommunication")
    public void setPharmacyCommunication(PharmacyCommunication pharmacyCommunication) {
        this.pharmacyCommunication = pharmacyCommunication;
    }

    @JsonProperty("pharmacySchedule")
    public Optional<List<OperatingHours>> getPharmacySchedule() {
        return Optional.ofNullable(pharmacySchedule);
    }

    @JsonProperty("pharmacySchedule")
    public void setPharmacySchedule(List<OperatingHours> pharmacySchedule) {
        this.pharmacySchedule = pharmacySchedule;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(RetailPharmacyLocation.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("pharmacyId");
        sb.append('=');
        sb.append(((this.pharmacyId == null)?"<null>":this.pharmacyId));
        sb.append(',');
        sb.append("pharmacyName");
        sb.append('=');
        sb.append(((this.pharmacyName == null)?"<null>":this.pharmacyName));
        sb.append(',');
        sb.append("distanceFromSearchLocation");
        sb.append('=');
        sb.append(this.distanceFromSearchLocation);
        sb.append(',');
        sb.append("pharmacyAddress");
        sb.append('=');
        sb.append(((this.pharmacyAddress == null)?"<null>":this.pharmacyAddress));
        sb.append(',');
        sb.append("pharmacyCommunication");
        sb.append('=');
        sb.append(((this.pharmacyCommunication == null)?"<null>":this.pharmacyCommunication));
        sb.append(',');
        sb.append("pharmacySchedule");
        sb.append('=');
        sb.append(((this.pharmacySchedule == null)?"<null>":this.pharmacySchedule));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.pharmacyId == null)? 0 :this.pharmacyId.hashCode()));
        result = ((result* 31)+((this.pharmacyCommunication == null)? 0 :this.pharmacyCommunication.hashCode()));
        result = ((result* 31)+((this.pharmacyAddress == null)? 0 :this.pharmacyAddress.hashCode()));
        result = ((result* 31)+((this.pharmacyName == null)? 0 :this.pharmacyName.hashCode()));
        result = ((result* 31)+((int)(Double.doubleToLongBits(this.distanceFromSearchLocation)^(Double.doubleToLongBits(this.distanceFromSearchLocation)>>> 32))));
        result = ((result* 31)+((this.pharmacySchedule == null)? 0 :this.pharmacySchedule.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RetailPharmacyLocation) == false) {
            return false;
        }
        RetailPharmacyLocation rhs = ((RetailPharmacyLocation) other);
        return (((((((this.pharmacyId == rhs.pharmacyId)||((this.pharmacyId!= null)&&this.pharmacyId.equals(rhs.pharmacyId)))&&((this.pharmacyCommunication == rhs.pharmacyCommunication)||((this.pharmacyCommunication!= null)&&this.pharmacyCommunication.equals(rhs.pharmacyCommunication))))&&((this.pharmacyAddress == rhs.pharmacyAddress)||((this.pharmacyAddress!= null)&&this.pharmacyAddress.equals(rhs.pharmacyAddress))))&&((this.pharmacyName == rhs.pharmacyName)||((this.pharmacyName!= null)&&this.pharmacyName.equals(rhs.pharmacyName))))&&(Double.doubleToLongBits(this.distanceFromSearchLocation) == Double.doubleToLongBits(rhs.distanceFromSearchLocation)))&&((this.pharmacySchedule == rhs.pharmacySchedule)||((this.pharmacySchedule!= null)&&this.pharmacySchedule.equals(rhs.pharmacySchedule))));
    }

    public static class RetailPharmacyLocationBuilder<T extends RetailPharmacyLocation >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public RetailPharmacyLocationBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(RetailPharmacyLocation.RetailPharmacyLocationBuilder.class)) {
                this.instance = ((T) new RetailPharmacyLocation());
            }
        }

        @SuppressWarnings("unchecked")
        public RetailPharmacyLocationBuilder(String pharmacyId, String pharmacyName, double distanceFromSearchLocation, PharmacyAddress pharmacyAddress, PharmacyCommunication pharmacyCommunication, List<OperatingHours> pharmacySchedule) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(RetailPharmacyLocation.RetailPharmacyLocationBuilder.class)) {
                this.instance = ((T) new RetailPharmacyLocation(pharmacyId, pharmacyName, distanceFromSearchLocation, pharmacyAddress, pharmacyCommunication, pharmacySchedule));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyId(String pharmacyId) {
            ((RetailPharmacyLocation) this.instance).pharmacyId = pharmacyId;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyName(String pharmacyName) {
            ((RetailPharmacyLocation) this.instance).pharmacyName = pharmacyName;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withDistanceFromSearchLocation(double distanceFromSearchLocation) {
            ((RetailPharmacyLocation) this.instance).distanceFromSearchLocation = distanceFromSearchLocation;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyAddress(PharmacyAddress pharmacyAddress) {
            ((RetailPharmacyLocation) this.instance).pharmacyAddress = pharmacyAddress;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyCommunication(PharmacyCommunication pharmacyCommunication) {
            ((RetailPharmacyLocation) this.instance).pharmacyCommunication = pharmacyCommunication;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacySchedule(List<OperatingHours> pharmacySchedule) {
            ((RetailPharmacyLocation) this.instance).pharmacySchedule = pharmacySchedule;
            return this;
        }

    }

}

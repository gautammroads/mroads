
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.cosmos;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * retailPharmacyLocation
 * <p>
 * 
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sourceSystemCode",
    "sourceSystemInstance",
    "affiliationId",
    "affiliationName",
    "pharmacyId",
    "pharmacyName",
    "npi",
    "ncpdp",
    "pharmacyStatus",
    "latitude",
    "longitude",
    "membershipRequired",
    "membershipDetailUrl",
    "logoImageURL",
    "darkModelImageUrl",
    "websiteUrl",
    "languageCode1",
    "languageCode1Desc",
    "languageCode2",
    "languageCode2Desc",
    "languageCode3",
    "languageCode3Desc",
    "languageCode4",
    "languageCode4Desc",
    "languageCode5",
    "languageCode5Desc",
    "affiliationCreateUser",
    "affiliationCreateDate",
    "affiliationUpdateUser",
    "affiliationUpdateDate",
    "pharmacyCreateUser",
    "pharmacyUpdateUser",
    "pharmacyCreateDate",
    "pharmacyUpdateDate",
    "azureCreateDate",
    "azureUpdateDate",
    "pharmacyAddress",
    "pharmacySchedule",
    "communication"
})
public class RetailPharmacyLocation {

    @JsonProperty("sourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("sourceSystemInstance")
    private String sourceSystemInstance;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("affiliationId")
    @NotNull
    private String affiliationId;
    @JsonProperty("affiliationName")
    private String affiliationName;
    @JsonProperty("pharmacyId")
    private String pharmacyId;
    @JsonProperty("pharmacyName")
    private String pharmacyName;
    @JsonProperty("npi")
    private String npi;
    @JsonProperty("ncpdp")
    private String ncpdp;
    @JsonProperty("pharmacyStatus")
    private String pharmacyStatus;
    @JsonProperty("latitude")
    private double latitude;
    @JsonProperty("longitude")
    private double longitude;
    @JsonProperty("membershipRequired")
    private String membershipRequired;
    @JsonProperty("membershipDetailUrl")
    private String membershipDetailUrl;
    @JsonProperty("logoImageURL")
    private String logoImageURL;
    @JsonProperty("darkModelImageUrl")
    private String darkModelImageUrl;
    @JsonProperty("websiteUrl")
    private String websiteUrl;
    @JsonProperty("languageCode1")
    private String languageCode1;
    @JsonProperty("languageCode1Desc")
    private String languageCode1Desc;
    @JsonProperty("languageCode2")
    private String languageCode2;
    @JsonProperty("languageCode2Desc")
    private String languageCode2Desc;
    @JsonProperty("languageCode3")
    private String languageCode3;
    @JsonProperty("languageCode3Desc")
    private String languageCode3Desc;
    @JsonProperty("languageCode4")
    private String languageCode4;
    @JsonProperty("languageCode4Desc")
    private String languageCode4Desc;
    @JsonProperty("languageCode5")
    private String languageCode5;
    @JsonProperty("languageCode5Desc")
    private String languageCode5Desc;
    @JsonProperty("affiliationCreateUser")
    private String affiliationCreateUser;
    @JsonProperty("affiliationCreateDate")
    private String affiliationCreateDate;
    @JsonProperty("affiliationUpdateUser")
    private String affiliationUpdateUser;
    @JsonProperty("affiliationUpdateDate")
    private String affiliationUpdateDate;
    @JsonProperty("pharmacyCreateUser")
    private String pharmacyCreateUser;
    @JsonProperty("pharmacyUpdateUser")
    private String pharmacyUpdateUser;
    @JsonProperty("pharmacyCreateDate")
    private String pharmacyCreateDate;
    @JsonProperty("pharmacyUpdateDate")
    private String pharmacyUpdateDate;
    @JsonProperty("azureCreateDate")
    private String azureCreateDate;
    @JsonProperty("azureUpdateDate")
    private String azureUpdateDate;
    @JsonProperty("pharmacyAddress")
    @Valid
    private List<PharmacyAddress> pharmacyAddress = new ArrayList<PharmacyAddress>();
    @JsonProperty("pharmacySchedule")
    @Valid
    private List<Schedule> pharmacySchedule = new ArrayList<Schedule>();
    @JsonProperty("communication")
    @Valid
    private List<Communication> communication = new ArrayList<Communication>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public RetailPharmacyLocation() {
    }

    /**
     * 
     * @param darkModelImageUrl
     * @param pharmacyAddress
     * @param affiliationUpdateUser
     * @param latitude
     * @param languageCode2Desc
     * @param pharmacyCreateDate
     * @param pharmacySchedule
     * @param azureCreateDate
     * @param membershipDetailUrl
     * @param membershipRequired
     * @param languageCode4Desc
     * @param websiteUrl
     * @param languageCode1Desc
     * @param pharmacyName
     * @param pharmacyUpdateUser
     * @param ncpdp
     * @param communication
     * @param sourceSystemCode
     * @param affiliationUpdateDate
     * @param longitude
     * @param languageCode5Desc
     * @param pharmacyId
     * @param affiliationCreateDate
     * @param pharmacyCreateUser
     * @param npi
     * @param sourceSystemInstance
     * @param logoImageURL
     * @param languageCode5
     * @param languageCode4
     * @param languageCode3
     * @param languageCode2
     * @param azureUpdateDate
     * @param pharmacyStatus
     * @param languageCode1
     * @param affiliationName
     * @param affiliationCreateUser
     * @param affiliationId
     * @param languageCode3Desc
     * @param pharmacyUpdateDate
     */
    public RetailPharmacyLocation(String sourceSystemCode, String sourceSystemInstance, String affiliationId, String affiliationName, String pharmacyId, String pharmacyName, String npi, String ncpdp, String pharmacyStatus, double latitude, double longitude, String membershipRequired, String membershipDetailUrl, String logoImageURL, String darkModelImageUrl, String websiteUrl, String languageCode1, String languageCode1Desc, String languageCode2, String languageCode2Desc, String languageCode3, String languageCode3Desc, String languageCode4, String languageCode4Desc, String languageCode5, String languageCode5Desc, String affiliationCreateUser, String affiliationCreateDate, String affiliationUpdateUser, String affiliationUpdateDate, String pharmacyCreateUser, String pharmacyUpdateUser, String pharmacyCreateDate, String pharmacyUpdateDate, String azureCreateDate, String azureUpdateDate, List<PharmacyAddress> pharmacyAddress, List<Schedule> pharmacySchedule, List<Communication> communication) {
        super();
        this.sourceSystemCode = sourceSystemCode;
        this.sourceSystemInstance = sourceSystemInstance;
        this.affiliationId = affiliationId;
        this.affiliationName = affiliationName;
        this.pharmacyId = pharmacyId;
        this.pharmacyName = pharmacyName;
        this.npi = npi;
        this.ncpdp = ncpdp;
        this.pharmacyStatus = pharmacyStatus;
        this.latitude = latitude;
        this.longitude = longitude;
        this.membershipRequired = membershipRequired;
        this.membershipDetailUrl = membershipDetailUrl;
        this.logoImageURL = logoImageURL;
        this.darkModelImageUrl = darkModelImageUrl;
        this.websiteUrl = websiteUrl;
        this.languageCode1 = languageCode1;
        this.languageCode1Desc = languageCode1Desc;
        this.languageCode2 = languageCode2;
        this.languageCode2Desc = languageCode2Desc;
        this.languageCode3 = languageCode3;
        this.languageCode3Desc = languageCode3Desc;
        this.languageCode4 = languageCode4;
        this.languageCode4Desc = languageCode4Desc;
        this.languageCode5 = languageCode5;
        this.languageCode5Desc = languageCode5Desc;
        this.affiliationCreateUser = affiliationCreateUser;
        this.affiliationCreateDate = affiliationCreateDate;
        this.affiliationUpdateUser = affiliationUpdateUser;
        this.affiliationUpdateDate = affiliationUpdateDate;
        this.pharmacyCreateUser = pharmacyCreateUser;
        this.pharmacyUpdateUser = pharmacyUpdateUser;
        this.pharmacyCreateDate = pharmacyCreateDate;
        this.pharmacyUpdateDate = pharmacyUpdateDate;
        this.azureCreateDate = azureCreateDate;
        this.azureUpdateDate = azureUpdateDate;
        this.pharmacyAddress = pharmacyAddress;
        this.pharmacySchedule = pharmacySchedule;
        this.communication = communication;
    }

    @JsonProperty("sourceSystemCode")
    public Optional<String> getSourceSystemCode() {
        return Optional.ofNullable(sourceSystemCode);
    }

    @JsonProperty("sourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    @JsonProperty("sourceSystemInstance")
    public Optional<String> getSourceSystemInstance() {
        return Optional.ofNullable(sourceSystemInstance);
    }

    @JsonProperty("sourceSystemInstance")
    public void setSourceSystemInstance(String sourceSystemInstance) {
        this.sourceSystemInstance = sourceSystemInstance;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("affiliationId")
    public String getAffiliationId() {
        return affiliationId;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("affiliationId")
    public void setAffiliationId(String affiliationId) {
        this.affiliationId = affiliationId;
    }

    @JsonProperty("affiliationName")
    public Optional<String> getAffiliationName() {
        return Optional.ofNullable(affiliationName);
    }

    @JsonProperty("affiliationName")
    public void setAffiliationName(String affiliationName) {
        this.affiliationName = affiliationName;
    }

    @JsonProperty("pharmacyId")
    public Optional<String> getPharmacyId() {
        return Optional.ofNullable(pharmacyId);
    }

    @JsonProperty("pharmacyId")
    public void setPharmacyId(String pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    @JsonProperty("pharmacyName")
    public Optional<String> getPharmacyName() {
        return Optional.ofNullable(pharmacyName);
    }

    @JsonProperty("pharmacyName")
    public void setPharmacyName(String pharmacyName) {
        this.pharmacyName = pharmacyName;
    }

    @JsonProperty("npi")
    public Optional<String> getNpi() {
        return Optional.ofNullable(npi);
    }

    @JsonProperty("npi")
    public void setNpi(String npi) {
        this.npi = npi;
    }

    @JsonProperty("ncpdp")
    public Optional<String> getNcpdp() {
        return Optional.ofNullable(ncpdp);
    }

    @JsonProperty("ncpdp")
    public void setNcpdp(String ncpdp) {
        this.ncpdp = ncpdp;
    }

    @JsonProperty("pharmacyStatus")
    public Optional<String> getPharmacyStatus() {
        return Optional.ofNullable(pharmacyStatus);
    }

    @JsonProperty("pharmacyStatus")
    public void setPharmacyStatus(String pharmacyStatus) {
        this.pharmacyStatus = pharmacyStatus;
    }

    @JsonProperty("latitude")
    public double getLatitude() {
        return latitude;
    }

    @JsonProperty("latitude")
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    @JsonProperty("longitude")
    public double getLongitude() {
        return longitude;
    }

    @JsonProperty("longitude")
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    @JsonProperty("membershipRequired")
    public Optional<String> getMembershipRequired() {
        return Optional.ofNullable(membershipRequired);
    }

    @JsonProperty("membershipRequired")
    public void setMembershipRequired(String membershipRequired) {
        this.membershipRequired = membershipRequired;
    }

    @JsonProperty("membershipDetailUrl")
    public Optional<String> getMembershipDetailUrl() {
        return Optional.ofNullable(membershipDetailUrl);
    }

    @JsonProperty("membershipDetailUrl")
    public void setMembershipDetailUrl(String membershipDetailUrl) {
        this.membershipDetailUrl = membershipDetailUrl;
    }

    @JsonProperty("logoImageURL")
    public Optional<String> getLogoImageURL() {
        return Optional.ofNullable(logoImageURL);
    }

    @JsonProperty("logoImageURL")
    public void setLogoImageURL(String logoImageURL) {
        this.logoImageURL = logoImageURL;
    }

    @JsonProperty("darkModelImageUrl")
    public Optional<String> getDarkModelImageUrl() {
        return Optional.ofNullable(darkModelImageUrl);
    }

    @JsonProperty("darkModelImageUrl")
    public void setDarkModelImageUrl(String darkModelImageUrl) {
        this.darkModelImageUrl = darkModelImageUrl;
    }

    @JsonProperty("websiteUrl")
    public Optional<String> getWebsiteUrl() {
        return Optional.ofNullable(websiteUrl);
    }

    @JsonProperty("websiteUrl")
    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    @JsonProperty("languageCode1")
    public Optional<String> getLanguageCode1() {
        return Optional.ofNullable(languageCode1);
    }

    @JsonProperty("languageCode1")
    public void setLanguageCode1(String languageCode1) {
        this.languageCode1 = languageCode1;
    }

    @JsonProperty("languageCode1Desc")
    public Optional<String> getLanguageCode1Desc() {
        return Optional.ofNullable(languageCode1Desc);
    }

    @JsonProperty("languageCode1Desc")
    public void setLanguageCode1Desc(String languageCode1Desc) {
        this.languageCode1Desc = languageCode1Desc;
    }

    @JsonProperty("languageCode2")
    public Optional<String> getLanguageCode2() {
        return Optional.ofNullable(languageCode2);
    }

    @JsonProperty("languageCode2")
    public void setLanguageCode2(String languageCode2) {
        this.languageCode2 = languageCode2;
    }

    @JsonProperty("languageCode2Desc")
    public Optional<String> getLanguageCode2Desc() {
        return Optional.ofNullable(languageCode2Desc);
    }

    @JsonProperty("languageCode2Desc")
    public void setLanguageCode2Desc(String languageCode2Desc) {
        this.languageCode2Desc = languageCode2Desc;
    }

    @JsonProperty("languageCode3")
    public Optional<String> getLanguageCode3() {
        return Optional.ofNullable(languageCode3);
    }

    @JsonProperty("languageCode3")
    public void setLanguageCode3(String languageCode3) {
        this.languageCode3 = languageCode3;
    }

    @JsonProperty("languageCode3Desc")
    public Optional<String> getLanguageCode3Desc() {
        return Optional.ofNullable(languageCode3Desc);
    }

    @JsonProperty("languageCode3Desc")
    public void setLanguageCode3Desc(String languageCode3Desc) {
        this.languageCode3Desc = languageCode3Desc;
    }

    @JsonProperty("languageCode4")
    public Optional<String> getLanguageCode4() {
        return Optional.ofNullable(languageCode4);
    }

    @JsonProperty("languageCode4")
    public void setLanguageCode4(String languageCode4) {
        this.languageCode4 = languageCode4;
    }

    @JsonProperty("languageCode4Desc")
    public Optional<String> getLanguageCode4Desc() {
        return Optional.ofNullable(languageCode4Desc);
    }

    @JsonProperty("languageCode4Desc")
    public void setLanguageCode4Desc(String languageCode4Desc) {
        this.languageCode4Desc = languageCode4Desc;
    }

    @JsonProperty("languageCode5")
    public Optional<String> getLanguageCode5() {
        return Optional.ofNullable(languageCode5);
    }

    @JsonProperty("languageCode5")
    public void setLanguageCode5(String languageCode5) {
        this.languageCode5 = languageCode5;
    }

    @JsonProperty("languageCode5Desc")
    public Optional<String> getLanguageCode5Desc() {
        return Optional.ofNullable(languageCode5Desc);
    }

    @JsonProperty("languageCode5Desc")
    public void setLanguageCode5Desc(String languageCode5Desc) {
        this.languageCode5Desc = languageCode5Desc;
    }

    @JsonProperty("affiliationCreateUser")
    public Optional<String> getAffiliationCreateUser() {
        return Optional.ofNullable(affiliationCreateUser);
    }

    @JsonProperty("affiliationCreateUser")
    public void setAffiliationCreateUser(String affiliationCreateUser) {
        this.affiliationCreateUser = affiliationCreateUser;
    }

    @JsonProperty("affiliationCreateDate")
    public Optional<String> getAffiliationCreateDate() {
        return Optional.ofNullable(affiliationCreateDate);
    }

    @JsonProperty("affiliationCreateDate")
    public void setAffiliationCreateDate(String affiliationCreateDate) {
        this.affiliationCreateDate = affiliationCreateDate;
    }

    @JsonProperty("affiliationUpdateUser")
    public Optional<String> getAffiliationUpdateUser() {
        return Optional.ofNullable(affiliationUpdateUser);
    }

    @JsonProperty("affiliationUpdateUser")
    public void setAffiliationUpdateUser(String affiliationUpdateUser) {
        this.affiliationUpdateUser = affiliationUpdateUser;
    }

    @JsonProperty("affiliationUpdateDate")
    public Optional<String> getAffiliationUpdateDate() {
        return Optional.ofNullable(affiliationUpdateDate);
    }

    @JsonProperty("affiliationUpdateDate")
    public void setAffiliationUpdateDate(String affiliationUpdateDate) {
        this.affiliationUpdateDate = affiliationUpdateDate;
    }

    @JsonProperty("pharmacyCreateUser")
    public Optional<String> getPharmacyCreateUser() {
        return Optional.ofNullable(pharmacyCreateUser);
    }

    @JsonProperty("pharmacyCreateUser")
    public void setPharmacyCreateUser(String pharmacyCreateUser) {
        this.pharmacyCreateUser = pharmacyCreateUser;
    }

    @JsonProperty("pharmacyUpdateUser")
    public Optional<String> getPharmacyUpdateUser() {
        return Optional.ofNullable(pharmacyUpdateUser);
    }

    @JsonProperty("pharmacyUpdateUser")
    public void setPharmacyUpdateUser(String pharmacyUpdateUser) {
        this.pharmacyUpdateUser = pharmacyUpdateUser;
    }

    @JsonProperty("pharmacyCreateDate")
    public Optional<String> getPharmacyCreateDate() {
        return Optional.ofNullable(pharmacyCreateDate);
    }

    @JsonProperty("pharmacyCreateDate")
    public void setPharmacyCreateDate(String pharmacyCreateDate) {
        this.pharmacyCreateDate = pharmacyCreateDate;
    }

    @JsonProperty("pharmacyUpdateDate")
    public Optional<String> getPharmacyUpdateDate() {
        return Optional.ofNullable(pharmacyUpdateDate);
    }

    @JsonProperty("pharmacyUpdateDate")
    public void setPharmacyUpdateDate(String pharmacyUpdateDate) {
        this.pharmacyUpdateDate = pharmacyUpdateDate;
    }

    @JsonProperty("azureCreateDate")
    public Optional<String> getAzureCreateDate() {
        return Optional.ofNullable(azureCreateDate);
    }

    @JsonProperty("azureCreateDate")
    public void setAzureCreateDate(String azureCreateDate) {
        this.azureCreateDate = azureCreateDate;
    }

    @JsonProperty("azureUpdateDate")
    public Optional<String> getAzureUpdateDate() {
        return Optional.ofNullable(azureUpdateDate);
    }

    @JsonProperty("azureUpdateDate")
    public void setAzureUpdateDate(String azureUpdateDate) {
        this.azureUpdateDate = azureUpdateDate;
    }

    @JsonProperty("pharmacyAddress")
    public Optional<List<PharmacyAddress>> getPharmacyAddress() {
        return Optional.ofNullable(pharmacyAddress);
    }

    @JsonProperty("pharmacyAddress")
    public void setPharmacyAddress(List<PharmacyAddress> pharmacyAddress) {
        this.pharmacyAddress = pharmacyAddress;
    }

    @JsonProperty("pharmacySchedule")
    public Optional<List<Schedule>> getPharmacySchedule() {
        return Optional.ofNullable(pharmacySchedule);
    }

    @JsonProperty("pharmacySchedule")
    public void setPharmacySchedule(List<Schedule> pharmacySchedule) {
        this.pharmacySchedule = pharmacySchedule;
    }

    @JsonProperty("communication")
    public Optional<List<Communication>> getCommunication() {
        return Optional.ofNullable(communication);
    }

    @JsonProperty("communication")
    public void setCommunication(List<Communication> communication) {
        this.communication = communication;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(RetailPharmacyLocation.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("sourceSystemCode");
        sb.append('=');
        sb.append(((this.sourceSystemCode == null)?"<null>":this.sourceSystemCode));
        sb.append(',');
        sb.append("sourceSystemInstance");
        sb.append('=');
        sb.append(((this.sourceSystemInstance == null)?"<null>":this.sourceSystemInstance));
        sb.append(',');
        sb.append("affiliationId");
        sb.append('=');
        sb.append(((this.affiliationId == null)?"<null>":this.affiliationId));
        sb.append(',');
        sb.append("affiliationName");
        sb.append('=');
        sb.append(((this.affiliationName == null)?"<null>":this.affiliationName));
        sb.append(',');
        sb.append("pharmacyId");
        sb.append('=');
        sb.append(((this.pharmacyId == null)?"<null>":this.pharmacyId));
        sb.append(',');
        sb.append("pharmacyName");
        sb.append('=');
        sb.append(((this.pharmacyName == null)?"<null>":this.pharmacyName));
        sb.append(',');
        sb.append("npi");
        sb.append('=');
        sb.append(((this.npi == null)?"<null>":this.npi));
        sb.append(',');
        sb.append("ncpdp");
        sb.append('=');
        sb.append(((this.ncpdp == null)?"<null>":this.ncpdp));
        sb.append(',');
        sb.append("pharmacyStatus");
        sb.append('=');
        sb.append(((this.pharmacyStatus == null)?"<null>":this.pharmacyStatus));
        sb.append(',');
        sb.append("latitude");
        sb.append('=');
        sb.append(this.latitude);
        sb.append(',');
        sb.append("longitude");
        sb.append('=');
        sb.append(this.longitude);
        sb.append(',');
        sb.append("membershipRequired");
        sb.append('=');
        sb.append(((this.membershipRequired == null)?"<null>":this.membershipRequired));
        sb.append(',');
        sb.append("membershipDetailUrl");
        sb.append('=');
        sb.append(((this.membershipDetailUrl == null)?"<null>":this.membershipDetailUrl));
        sb.append(',');
        sb.append("logoImageURL");
        sb.append('=');
        sb.append(((this.logoImageURL == null)?"<null>":this.logoImageURL));
        sb.append(',');
        sb.append("darkModelImageUrl");
        sb.append('=');
        sb.append(((this.darkModelImageUrl == null)?"<null>":this.darkModelImageUrl));
        sb.append(',');
        sb.append("websiteUrl");
        sb.append('=');
        sb.append(((this.websiteUrl == null)?"<null>":this.websiteUrl));
        sb.append(',');
        sb.append("languageCode1");
        sb.append('=');
        sb.append(((this.languageCode1 == null)?"<null>":this.languageCode1));
        sb.append(',');
        sb.append("languageCode1Desc");
        sb.append('=');
        sb.append(((this.languageCode1Desc == null)?"<null>":this.languageCode1Desc));
        sb.append(',');
        sb.append("languageCode2");
        sb.append('=');
        sb.append(((this.languageCode2 == null)?"<null>":this.languageCode2));
        sb.append(',');
        sb.append("languageCode2Desc");
        sb.append('=');
        sb.append(((this.languageCode2Desc == null)?"<null>":this.languageCode2Desc));
        sb.append(',');
        sb.append("languageCode3");
        sb.append('=');
        sb.append(((this.languageCode3 == null)?"<null>":this.languageCode3));
        sb.append(',');
        sb.append("languageCode3Desc");
        sb.append('=');
        sb.append(((this.languageCode3Desc == null)?"<null>":this.languageCode3Desc));
        sb.append(',');
        sb.append("languageCode4");
        sb.append('=');
        sb.append(((this.languageCode4 == null)?"<null>":this.languageCode4));
        sb.append(',');
        sb.append("languageCode4Desc");
        sb.append('=');
        sb.append(((this.languageCode4Desc == null)?"<null>":this.languageCode4Desc));
        sb.append(',');
        sb.append("languageCode5");
        sb.append('=');
        sb.append(((this.languageCode5 == null)?"<null>":this.languageCode5));
        sb.append(',');
        sb.append("languageCode5Desc");
        sb.append('=');
        sb.append(((this.languageCode5Desc == null)?"<null>":this.languageCode5Desc));
        sb.append(',');
        sb.append("affiliationCreateUser");
        sb.append('=');
        sb.append(((this.affiliationCreateUser == null)?"<null>":this.affiliationCreateUser));
        sb.append(',');
        sb.append("affiliationCreateDate");
        sb.append('=');
        sb.append(((this.affiliationCreateDate == null)?"<null>":this.affiliationCreateDate));
        sb.append(',');
        sb.append("affiliationUpdateUser");
        sb.append('=');
        sb.append(((this.affiliationUpdateUser == null)?"<null>":this.affiliationUpdateUser));
        sb.append(',');
        sb.append("affiliationUpdateDate");
        sb.append('=');
        sb.append(((this.affiliationUpdateDate == null)?"<null>":this.affiliationUpdateDate));
        sb.append(',');
        sb.append("pharmacyCreateUser");
        sb.append('=');
        sb.append(((this.pharmacyCreateUser == null)?"<null>":this.pharmacyCreateUser));
        sb.append(',');
        sb.append("pharmacyUpdateUser");
        sb.append('=');
        sb.append(((this.pharmacyUpdateUser == null)?"<null>":this.pharmacyUpdateUser));
        sb.append(',');
        sb.append("pharmacyCreateDate");
        sb.append('=');
        sb.append(((this.pharmacyCreateDate == null)?"<null>":this.pharmacyCreateDate));
        sb.append(',');
        sb.append("pharmacyUpdateDate");
        sb.append('=');
        sb.append(((this.pharmacyUpdateDate == null)?"<null>":this.pharmacyUpdateDate));
        sb.append(',');
        sb.append("azureCreateDate");
        sb.append('=');
        sb.append(((this.azureCreateDate == null)?"<null>":this.azureCreateDate));
        sb.append(',');
        sb.append("azureUpdateDate");
        sb.append('=');
        sb.append(((this.azureUpdateDate == null)?"<null>":this.azureUpdateDate));
        sb.append(',');
        sb.append("pharmacyAddress");
        sb.append('=');
        sb.append(((this.pharmacyAddress == null)?"<null>":this.pharmacyAddress));
        sb.append(',');
        sb.append("pharmacySchedule");
        sb.append('=');
        sb.append(((this.pharmacySchedule == null)?"<null>":this.pharmacySchedule));
        sb.append(',');
        sb.append("communication");
        sb.append('=');
        sb.append(((this.communication == null)?"<null>":this.communication));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.darkModelImageUrl == null)? 0 :this.darkModelImageUrl.hashCode()));
        result = ((result* 31)+((this.pharmacyAddress == null)? 0 :this.pharmacyAddress.hashCode()));
        result = ((result* 31)+((this.affiliationUpdateUser == null)? 0 :this.affiliationUpdateUser.hashCode()));
        result = ((result* 31)+((int)(Double.doubleToLongBits(this.latitude)^(Double.doubleToLongBits(this.latitude)>>> 32))));
        result = ((result* 31)+((this.languageCode2Desc == null)? 0 :this.languageCode2Desc.hashCode()));
        result = ((result* 31)+((this.pharmacyCreateDate == null)? 0 :this.pharmacyCreateDate.hashCode()));
        result = ((result* 31)+((this.pharmacySchedule == null)? 0 :this.pharmacySchedule.hashCode()));
        result = ((result* 31)+((this.azureCreateDate == null)? 0 :this.azureCreateDate.hashCode()));
        result = ((result* 31)+((this.membershipDetailUrl == null)? 0 :this.membershipDetailUrl.hashCode()));
        result = ((result* 31)+((this.membershipRequired == null)? 0 :this.membershipRequired.hashCode()));
        result = ((result* 31)+((this.languageCode4Desc == null)? 0 :this.languageCode4Desc.hashCode()));
        result = ((result* 31)+((this.websiteUrl == null)? 0 :this.websiteUrl.hashCode()));
        result = ((result* 31)+((this.languageCode1Desc == null)? 0 :this.languageCode1Desc.hashCode()));
        result = ((result* 31)+((this.pharmacyName == null)? 0 :this.pharmacyName.hashCode()));
        result = ((result* 31)+((this.pharmacyUpdateUser == null)? 0 :this.pharmacyUpdateUser.hashCode()));
        result = ((result* 31)+((this.ncpdp == null)? 0 :this.ncpdp.hashCode()));
        result = ((result* 31)+((this.communication == null)? 0 :this.communication.hashCode()));
        result = ((result* 31)+((this.sourceSystemCode == null)? 0 :this.sourceSystemCode.hashCode()));
        result = ((result* 31)+((this.affiliationUpdateDate == null)? 0 :this.affiliationUpdateDate.hashCode()));
        result = ((result* 31)+((int)(Double.doubleToLongBits(this.longitude)^(Double.doubleToLongBits(this.longitude)>>> 32))));
        result = ((result* 31)+((this.languageCode5Desc == null)? 0 :this.languageCode5Desc.hashCode()));
        result = ((result* 31)+((this.pharmacyId == null)? 0 :this.pharmacyId.hashCode()));
        result = ((result* 31)+((this.affiliationCreateDate == null)? 0 :this.affiliationCreateDate.hashCode()));
        result = ((result* 31)+((this.pharmacyCreateUser == null)? 0 :this.pharmacyCreateUser.hashCode()));
        result = ((result* 31)+((this.npi == null)? 0 :this.npi.hashCode()));
        result = ((result* 31)+((this.sourceSystemInstance == null)? 0 :this.sourceSystemInstance.hashCode()));
        result = ((result* 31)+((this.logoImageURL == null)? 0 :this.logoImageURL.hashCode()));
        result = ((result* 31)+((this.languageCode5 == null)? 0 :this.languageCode5 .hashCode()));
        result = ((result* 31)+((this.languageCode4 == null)? 0 :this.languageCode4 .hashCode()));
        result = ((result* 31)+((this.languageCode3 == null)? 0 :this.languageCode3 .hashCode()));
        result = ((result* 31)+((this.languageCode2 == null)? 0 :this.languageCode2 .hashCode()));
        result = ((result* 31)+((this.azureUpdateDate == null)? 0 :this.azureUpdateDate.hashCode()));
        result = ((result* 31)+((this.pharmacyStatus == null)? 0 :this.pharmacyStatus.hashCode()));
        result = ((result* 31)+((this.languageCode1 == null)? 0 :this.languageCode1 .hashCode()));
        result = ((result* 31)+((this.affiliationName == null)? 0 :this.affiliationName.hashCode()));
        result = ((result* 31)+((this.affiliationCreateUser == null)? 0 :this.affiliationCreateUser.hashCode()));
        result = ((result* 31)+((this.affiliationId == null)? 0 :this.affiliationId.hashCode()));
        result = ((result* 31)+((this.languageCode3Desc == null)? 0 :this.languageCode3Desc.hashCode()));
        result = ((result* 31)+((this.pharmacyUpdateDate == null)? 0 :this.pharmacyUpdateDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RetailPharmacyLocation) == false) {
            return false;
        }
        RetailPharmacyLocation rhs = ((RetailPharmacyLocation) other);
        return ((((((((((((((((((((((((((((((((((((((((this.darkModelImageUrl == rhs.darkModelImageUrl)||((this.darkModelImageUrl!= null)&&this.darkModelImageUrl.equals(rhs.darkModelImageUrl)))&&((this.pharmacyAddress == rhs.pharmacyAddress)||((this.pharmacyAddress!= null)&&this.pharmacyAddress.equals(rhs.pharmacyAddress))))&&((this.affiliationUpdateUser == rhs.affiliationUpdateUser)||((this.affiliationUpdateUser!= null)&&this.affiliationUpdateUser.equals(rhs.affiliationUpdateUser))))&&(Double.doubleToLongBits(this.latitude) == Double.doubleToLongBits(rhs.latitude)))&&((this.languageCode2Desc == rhs.languageCode2Desc)||((this.languageCode2Desc!= null)&&this.languageCode2Desc.equals(rhs.languageCode2Desc))))&&((this.pharmacyCreateDate == rhs.pharmacyCreateDate)||((this.pharmacyCreateDate!= null)&&this.pharmacyCreateDate.equals(rhs.pharmacyCreateDate))))&&((this.pharmacySchedule == rhs.pharmacySchedule)||((this.pharmacySchedule!= null)&&this.pharmacySchedule.equals(rhs.pharmacySchedule))))&&((this.azureCreateDate == rhs.azureCreateDate)||((this.azureCreateDate!= null)&&this.azureCreateDate.equals(rhs.azureCreateDate))))&&((this.membershipDetailUrl == rhs.membershipDetailUrl)||((this.membershipDetailUrl!= null)&&this.membershipDetailUrl.equals(rhs.membershipDetailUrl))))&&((this.membershipRequired == rhs.membershipRequired)||((this.membershipRequired!= null)&&this.membershipRequired.equals(rhs.membershipRequired))))&&((this.languageCode4Desc == rhs.languageCode4Desc)||((this.languageCode4Desc!= null)&&this.languageCode4Desc.equals(rhs.languageCode4Desc))))&&((this.websiteUrl == rhs.websiteUrl)||((this.websiteUrl!= null)&&this.websiteUrl.equals(rhs.websiteUrl))))&&((this.languageCode1Desc == rhs.languageCode1Desc)||((this.languageCode1Desc!= null)&&this.languageCode1Desc.equals(rhs.languageCode1Desc))))&&((this.pharmacyName == rhs.pharmacyName)||((this.pharmacyName!= null)&&this.pharmacyName.equals(rhs.pharmacyName))))&&((this.pharmacyUpdateUser == rhs.pharmacyUpdateUser)||((this.pharmacyUpdateUser!= null)&&this.pharmacyUpdateUser.equals(rhs.pharmacyUpdateUser))))&&((this.ncpdp == rhs.ncpdp)||((this.ncpdp!= null)&&this.ncpdp.equals(rhs.ncpdp))))&&((this.communication == rhs.communication)||((this.communication!= null)&&this.communication.equals(rhs.communication))))&&((this.sourceSystemCode == rhs.sourceSystemCode)||((this.sourceSystemCode!= null)&&this.sourceSystemCode.equals(rhs.sourceSystemCode))))&&((this.affiliationUpdateDate == rhs.affiliationUpdateDate)||((this.affiliationUpdateDate!= null)&&this.affiliationUpdateDate.equals(rhs.affiliationUpdateDate))))&&(Double.doubleToLongBits(this.longitude) == Double.doubleToLongBits(rhs.longitude)))&&((this.languageCode5Desc == rhs.languageCode5Desc)||((this.languageCode5Desc!= null)&&this.languageCode5Desc.equals(rhs.languageCode5Desc))))&&((this.pharmacyId == rhs.pharmacyId)||((this.pharmacyId!= null)&&this.pharmacyId.equals(rhs.pharmacyId))))&&((this.affiliationCreateDate == rhs.affiliationCreateDate)||((this.affiliationCreateDate!= null)&&this.affiliationCreateDate.equals(rhs.affiliationCreateDate))))&&((this.pharmacyCreateUser == rhs.pharmacyCreateUser)||((this.pharmacyCreateUser!= null)&&this.pharmacyCreateUser.equals(rhs.pharmacyCreateUser))))&&((this.npi == rhs.npi)||((this.npi!= null)&&this.npi.equals(rhs.npi))))&&((this.sourceSystemInstance == rhs.sourceSystemInstance)||((this.sourceSystemInstance!= null)&&this.sourceSystemInstance.equals(rhs.sourceSystemInstance))))&&((this.logoImageURL == rhs.logoImageURL)||((this.logoImageURL!= null)&&this.logoImageURL.equals(rhs.logoImageURL))))&&((this.languageCode5 == rhs.languageCode5)||((this.languageCode5 != null)&&this.languageCode5 .equals(rhs.languageCode5))))&&((this.languageCode4 == rhs.languageCode4)||((this.languageCode4 != null)&&this.languageCode4 .equals(rhs.languageCode4))))&&((this.languageCode3 == rhs.languageCode3)||((this.languageCode3 != null)&&this.languageCode3 .equals(rhs.languageCode3))))&&((this.languageCode2 == rhs.languageCode2)||((this.languageCode2 != null)&&this.languageCode2 .equals(rhs.languageCode2))))&&((this.azureUpdateDate == rhs.azureUpdateDate)||((this.azureUpdateDate!= null)&&this.azureUpdateDate.equals(rhs.azureUpdateDate))))&&((this.pharmacyStatus == rhs.pharmacyStatus)||((this.pharmacyStatus!= null)&&this.pharmacyStatus.equals(rhs.pharmacyStatus))))&&((this.languageCode1 == rhs.languageCode1)||((this.languageCode1 != null)&&this.languageCode1 .equals(rhs.languageCode1))))&&((this.affiliationName == rhs.affiliationName)||((this.affiliationName!= null)&&this.affiliationName.equals(rhs.affiliationName))))&&((this.affiliationCreateUser == rhs.affiliationCreateUser)||((this.affiliationCreateUser!= null)&&this.affiliationCreateUser.equals(rhs.affiliationCreateUser))))&&((this.affiliationId == rhs.affiliationId)||((this.affiliationId!= null)&&this.affiliationId.equals(rhs.affiliationId))))&&((this.languageCode3Desc == rhs.languageCode3Desc)||((this.languageCode3Desc!= null)&&this.languageCode3Desc.equals(rhs.languageCode3Desc))))&&((this.pharmacyUpdateDate == rhs.pharmacyUpdateDate)||((this.pharmacyUpdateDate!= null)&&this.pharmacyUpdateDate.equals(rhs.pharmacyUpdateDate))));
    }

    public static class RetailPharmacyLocationBuilder<T extends RetailPharmacyLocation >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public RetailPharmacyLocationBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(RetailPharmacyLocation.RetailPharmacyLocationBuilder.class)) {
                this.instance = ((T) new RetailPharmacyLocation());
            }
        }

        @SuppressWarnings("unchecked")
        public RetailPharmacyLocationBuilder(String sourceSystemCode, String sourceSystemInstance, String affiliationId, String affiliationName, String pharmacyId, String pharmacyName, String npi, String ncpdp, String pharmacyStatus, double latitude, double longitude, String membershipRequired, String membershipDetailUrl, String logoImageURL, String darkModelImageUrl, String websiteUrl, String languageCode1, String languageCode1Desc, String languageCode2, String languageCode2Desc, String languageCode3, String languageCode3Desc, String languageCode4, String languageCode4Desc, String languageCode5, String languageCode5Desc, String affiliationCreateUser, String affiliationCreateDate, String affiliationUpdateUser, String affiliationUpdateDate, String pharmacyCreateUser, String pharmacyUpdateUser, String pharmacyCreateDate, String pharmacyUpdateDate, String azureCreateDate, String azureUpdateDate, List<PharmacyAddress> pharmacyAddress, List<Schedule> pharmacySchedule, List<Communication> communication) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(RetailPharmacyLocation.RetailPharmacyLocationBuilder.class)) {
                this.instance = ((T) new RetailPharmacyLocation(sourceSystemCode, sourceSystemInstance, affiliationId, affiliationName, pharmacyId, pharmacyName, npi, ncpdp, pharmacyStatus, latitude, longitude, membershipRequired, membershipDetailUrl, logoImageURL, darkModelImageUrl, websiteUrl, languageCode1, languageCode1Desc, languageCode2, languageCode2Desc, languageCode3, languageCode3Desc, languageCode4, languageCode4Desc, languageCode5, languageCode5Desc, affiliationCreateUser, affiliationCreateDate, affiliationUpdateUser, affiliationUpdateDate, pharmacyCreateUser, pharmacyUpdateUser, pharmacyCreateDate, pharmacyUpdateDate, azureCreateDate, azureUpdateDate, pharmacyAddress, pharmacySchedule, communication));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withSourceSystemCode(String sourceSystemCode) {
            ((RetailPharmacyLocation) this.instance).sourceSystemCode = sourceSystemCode;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withSourceSystemInstance(String sourceSystemInstance) {
            ((RetailPharmacyLocation) this.instance).sourceSystemInstance = sourceSystemInstance;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAffiliationId(String affiliationId) {
            ((RetailPharmacyLocation) this.instance).affiliationId = affiliationId;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAffiliationName(String affiliationName) {
            ((RetailPharmacyLocation) this.instance).affiliationName = affiliationName;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyId(String pharmacyId) {
            ((RetailPharmacyLocation) this.instance).pharmacyId = pharmacyId;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyName(String pharmacyName) {
            ((RetailPharmacyLocation) this.instance).pharmacyName = pharmacyName;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withNpi(String npi) {
            ((RetailPharmacyLocation) this.instance).npi = npi;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withNcpdp(String ncpdp) {
            ((RetailPharmacyLocation) this.instance).ncpdp = ncpdp;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyStatus(String pharmacyStatus) {
            ((RetailPharmacyLocation) this.instance).pharmacyStatus = pharmacyStatus;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLatitude(double latitude) {
            ((RetailPharmacyLocation) this.instance).latitude = latitude;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLongitude(double longitude) {
            ((RetailPharmacyLocation) this.instance).longitude = longitude;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withMembershipRequired(String membershipRequired) {
            ((RetailPharmacyLocation) this.instance).membershipRequired = membershipRequired;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withMembershipDetailUrl(String membershipDetailUrl) {
            ((RetailPharmacyLocation) this.instance).membershipDetailUrl = membershipDetailUrl;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLogoImageURL(String logoImageURL) {
            ((RetailPharmacyLocation) this.instance).logoImageURL = logoImageURL;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withDarkModelImageUrl(String darkModelImageUrl) {
            ((RetailPharmacyLocation) this.instance).darkModelImageUrl = darkModelImageUrl;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withWebsiteUrl(String websiteUrl) {
            ((RetailPharmacyLocation) this.instance).websiteUrl = websiteUrl;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode1(String languageCode1) {
            ((RetailPharmacyLocation) this.instance).languageCode1 = languageCode1;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode1Desc(String languageCode1Desc) {
            ((RetailPharmacyLocation) this.instance).languageCode1Desc = languageCode1Desc;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode2(String languageCode2) {
            ((RetailPharmacyLocation) this.instance).languageCode2 = languageCode2;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode2Desc(String languageCode2Desc) {
            ((RetailPharmacyLocation) this.instance).languageCode2Desc = languageCode2Desc;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode3(String languageCode3) {
            ((RetailPharmacyLocation) this.instance).languageCode3 = languageCode3;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode3Desc(String languageCode3Desc) {
            ((RetailPharmacyLocation) this.instance).languageCode3Desc = languageCode3Desc;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode4(String languageCode4) {
            ((RetailPharmacyLocation) this.instance).languageCode4 = languageCode4;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode4Desc(String languageCode4Desc) {
            ((RetailPharmacyLocation) this.instance).languageCode4Desc = languageCode4Desc;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode5(String languageCode5) {
            ((RetailPharmacyLocation) this.instance).languageCode5 = languageCode5;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withLanguageCode5Desc(String languageCode5Desc) {
            ((RetailPharmacyLocation) this.instance).languageCode5Desc = languageCode5Desc;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAffiliationCreateUser(String affiliationCreateUser) {
            ((RetailPharmacyLocation) this.instance).affiliationCreateUser = affiliationCreateUser;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAffiliationCreateDate(String affiliationCreateDate) {
            ((RetailPharmacyLocation) this.instance).affiliationCreateDate = affiliationCreateDate;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAffiliationUpdateUser(String affiliationUpdateUser) {
            ((RetailPharmacyLocation) this.instance).affiliationUpdateUser = affiliationUpdateUser;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAffiliationUpdateDate(String affiliationUpdateDate) {
            ((RetailPharmacyLocation) this.instance).affiliationUpdateDate = affiliationUpdateDate;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyCreateUser(String pharmacyCreateUser) {
            ((RetailPharmacyLocation) this.instance).pharmacyCreateUser = pharmacyCreateUser;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyUpdateUser(String pharmacyUpdateUser) {
            ((RetailPharmacyLocation) this.instance).pharmacyUpdateUser = pharmacyUpdateUser;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyCreateDate(String pharmacyCreateDate) {
            ((RetailPharmacyLocation) this.instance).pharmacyCreateDate = pharmacyCreateDate;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyUpdateDate(String pharmacyUpdateDate) {
            ((RetailPharmacyLocation) this.instance).pharmacyUpdateDate = pharmacyUpdateDate;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAzureCreateDate(String azureCreateDate) {
            ((RetailPharmacyLocation) this.instance).azureCreateDate = azureCreateDate;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withAzureUpdateDate(String azureUpdateDate) {
            ((RetailPharmacyLocation) this.instance).azureUpdateDate = azureUpdateDate;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacyAddress(List<PharmacyAddress> pharmacyAddress) {
            ((RetailPharmacyLocation) this.instance).pharmacyAddress = pharmacyAddress;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withPharmacySchedule(List<Schedule> pharmacySchedule) {
            ((RetailPharmacyLocation) this.instance).pharmacySchedule = pharmacySchedule;
            return this;
        }

        public RetailPharmacyLocation.RetailPharmacyLocationBuilder withCommunication(List<Communication> communication) {
            ((RetailPharmacyLocation) this.instance).communication = communication;
            return this;
        }

    }

}


package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption;

import java.util.Optional;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * pharmacyAddress
 * <p>
 * 
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "addressLine1",
    "addressLine2",
    "city",
    "state",
    "postalCode",
    "latitudeDegree",
    "longitudeDegree",
    "geoJsonLocation"
})
public class PharmacyAddress {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("addressLine1")
    @NotNull
    private String addressLine1;
    @JsonProperty("addressLine2")
    private String addressLine2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("postalCode")
    @NotNull
    private String postalCode;
    @JsonProperty("latitudeDegree")
    private double latitudeDegree;
    @JsonProperty("longitudeDegree")
    private double longitudeDegree;
    /**
     * GeoJSON Point
     * <p>
     * 
     * 
     */
    @JsonProperty("geoJsonLocation")
    @Valid
    private Point geoJsonLocation;

    /**
     * No args constructor for use in serialization
     * 
     */
    public PharmacyAddress() {
    }

    /**
     * 
     * @param city
     * @param postalCode
     * @param addressLine1
     * @param geoJsonLocation
     * @param addressLine2
     * @param longitudeDegree
     * @param state
     * @param latitudeDegree
     */
    public PharmacyAddress(String addressLine1, String addressLine2, String city, String state, String postalCode, double latitudeDegree, double longitudeDegree, Point geoJsonLocation) {
        super();
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.state = state;
        this.postalCode = postalCode;
        this.latitudeDegree = latitudeDegree;
        this.longitudeDegree = longitudeDegree;
        this.geoJsonLocation = geoJsonLocation;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("addressLine1")
    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("addressLine1")
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    @JsonProperty("addressLine2")
    public Optional<String> getAddressLine2() {
        return Optional.ofNullable(addressLine2);
    }

    @JsonProperty("addressLine2")
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    @JsonProperty("city")
    public Optional<String> getCity() {
        return Optional.ofNullable(city);
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("state")
    public Optional<String> getState() {
        return Optional.ofNullable(state);
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("postalCode")
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("postalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonProperty("latitudeDegree")
    public double getLatitudeDegree() {
        return latitudeDegree;
    }

    @JsonProperty("latitudeDegree")
    public void setLatitudeDegree(double latitudeDegree) {
        this.latitudeDegree = latitudeDegree;
    }

    @JsonProperty("longitudeDegree")
    public double getLongitudeDegree() {
        return longitudeDegree;
    }

    @JsonProperty("longitudeDegree")
    public void setLongitudeDegree(double longitudeDegree) {
        this.longitudeDegree = longitudeDegree;
    }

    /**
     * GeoJSON Point
     * <p>
     * 
     * 
     */
    @JsonProperty("geoJsonLocation")
    public Optional<Point> getGeoJsonLocation() {
        return Optional.ofNullable(geoJsonLocation);
    }

    /**
     * GeoJSON Point
     * <p>
     * 
     * 
     */
    @JsonProperty("geoJsonLocation")
    public void setGeoJsonLocation(Point geoJsonLocation) {
        this.geoJsonLocation = geoJsonLocation;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PharmacyAddress.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("addressLine1");
        sb.append('=');
        sb.append(((this.addressLine1 == null)?"<null>":this.addressLine1));
        sb.append(',');
        sb.append("addressLine2");
        sb.append('=');
        sb.append(((this.addressLine2 == null)?"<null>":this.addressLine2));
        sb.append(',');
        sb.append("city");
        sb.append('=');
        sb.append(((this.city == null)?"<null>":this.city));
        sb.append(',');
        sb.append("state");
        sb.append('=');
        sb.append(((this.state == null)?"<null>":this.state));
        sb.append(',');
        sb.append("postalCode");
        sb.append('=');
        sb.append(((this.postalCode == null)?"<null>":this.postalCode));
        sb.append(',');
        sb.append("latitudeDegree");
        sb.append('=');
        sb.append(this.latitudeDegree);
        sb.append(',');
        sb.append("longitudeDegree");
        sb.append('=');
        sb.append(this.longitudeDegree);
        sb.append(',');
        sb.append("geoJsonLocation");
        sb.append('=');
        sb.append(((this.geoJsonLocation == null)?"<null>":this.geoJsonLocation));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.city == null)? 0 :this.city.hashCode()));
        result = ((result* 31)+((this.postalCode == null)? 0 :this.postalCode.hashCode()));
        result = ((result* 31)+((this.addressLine1 == null)? 0 :this.addressLine1 .hashCode()));
        result = ((result* 31)+((this.geoJsonLocation == null)? 0 :this.geoJsonLocation.hashCode()));
        result = ((result* 31)+((this.addressLine2 == null)? 0 :this.addressLine2 .hashCode()));
        result = ((result* 31)+((int)(Double.doubleToLongBits(this.longitudeDegree)^(Double.doubleToLongBits(this.longitudeDegree)>>> 32))));
        result = ((result* 31)+((this.state == null)? 0 :this.state.hashCode()));
        result = ((result* 31)+((int)(Double.doubleToLongBits(this.latitudeDegree)^(Double.doubleToLongBits(this.latitudeDegree)>>> 32))));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PharmacyAddress) == false) {
            return false;
        }
        PharmacyAddress rhs = ((PharmacyAddress) other);
        return (((((((((this.city == rhs.city)||((this.city!= null)&&this.city.equals(rhs.city)))&&((this.postalCode == rhs.postalCode)||((this.postalCode!= null)&&this.postalCode.equals(rhs.postalCode))))&&((this.addressLine1 == rhs.addressLine1)||((this.addressLine1 != null)&&this.addressLine1 .equals(rhs.addressLine1))))&&((this.geoJsonLocation == rhs.geoJsonLocation)||((this.geoJsonLocation!= null)&&this.geoJsonLocation.equals(rhs.geoJsonLocation))))&&((this.addressLine2 == rhs.addressLine2)||((this.addressLine2 != null)&&this.addressLine2 .equals(rhs.addressLine2))))&&(Double.doubleToLongBits(this.longitudeDegree) == Double.doubleToLongBits(rhs.longitudeDegree)))&&((this.state == rhs.state)||((this.state!= null)&&this.state.equals(rhs.state))))&&(Double.doubleToLongBits(this.latitudeDegree) == Double.doubleToLongBits(rhs.latitudeDegree)));
    }

    public static class PharmacyAddressBuilder<T extends PharmacyAddress >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public PharmacyAddressBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyAddress.PharmacyAddressBuilder.class)) {
                this.instance = ((T) new PharmacyAddress());
            }
        }

        @SuppressWarnings("unchecked")
        public PharmacyAddressBuilder(String addressLine1, String addressLine2, String city, String state, String postalCode, double latitudeDegree, double longitudeDegree, Point geoJsonLocation) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyAddress.PharmacyAddressBuilder.class)) {
                this.instance = ((T) new PharmacyAddress(addressLine1, addressLine2, city, state, postalCode, latitudeDegree, longitudeDegree, geoJsonLocation));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public PharmacyAddress.PharmacyAddressBuilder withAddressLine1(String addressLine1) {
            ((PharmacyAddress) this.instance).addressLine1 = addressLine1;
            return this;
        }

        public PharmacyAddress.PharmacyAddressBuilder withAddressLine2(String addressLine2) {
            ((PharmacyAddress) this.instance).addressLine2 = addressLine2;
            return this;
        }

        public PharmacyAddress.PharmacyAddressBuilder withCity(String city) {
            ((PharmacyAddress) this.instance).city = city;
            return this;
        }

        public PharmacyAddress.PharmacyAddressBuilder withState(String state) {
            ((PharmacyAddress) this.instance).state = state;
            return this;
        }

        public PharmacyAddress.PharmacyAddressBuilder withPostalCode(String postalCode) {
            ((PharmacyAddress) this.instance).postalCode = postalCode;
            return this;
        }

        public PharmacyAddress.PharmacyAddressBuilder withLatitudeDegree(double latitudeDegree) {
            ((PharmacyAddress) this.instance).latitudeDegree = latitudeDegree;
            return this;
        }

        public PharmacyAddress.PharmacyAddressBuilder withLongitudeDegree(double longitudeDegree) {
            ((PharmacyAddress) this.instance).longitudeDegree = longitudeDegree;
            return this;
        }

        public PharmacyAddress.PharmacyAddressBuilder withGeoJsonLocation(Point geoJsonLocation) {
            ((PharmacyAddress) this.instance).geoJsonLocation = geoJsonLocation;
            return this;
        }

    }

}

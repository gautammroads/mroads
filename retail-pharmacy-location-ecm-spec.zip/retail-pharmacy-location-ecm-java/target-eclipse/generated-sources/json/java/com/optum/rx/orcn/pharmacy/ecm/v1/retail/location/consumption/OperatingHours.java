
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonValue;


/**
 * hours
 * <p>
 * 
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dayOfWeek",
    "openingTime",
    "closingTime",
    "timeZone"
})
public class OperatingHours {

    /**
     * The days of the week with the addition of a special HOLIDAY element
     * (Required)
     * 
     */
    @JsonProperty("dayOfWeek")
    @JsonPropertyDescription("The days of the week with the addition of a special HOLIDAY element")
    @NotNull
    private OperatingHours.DayOfWeek dayOfWeek;
    /**
     * The opening time of the location in ISO 8601 time of day format
     * (Required)
     * 
     */
    @JsonProperty("openingTime")
    @JsonPropertyDescription("The opening time of the location in ISO 8601 time of day format")
    @NotNull
    private String openingTime;
    /**
     * The closing time of the location in ISO 8601 time of day format
     * (Required)
     * 
     */
    @JsonProperty("closingTime")
    @JsonPropertyDescription("The closing time of the location in ISO 8601 time of day format")
    @NotNull
    private String closingTime;
    /**
     * The tz database name for this location's time zone
     * 
     */
    @JsonProperty("timeZone")
    @JsonPropertyDescription("The tz database name for this location's time zone")
    private String timeZone;

    /**
     * No args constructor for use in serialization
     * 
     */
    public OperatingHours() {
    }

    /**
     * 
     * @param dayOfWeek
     * @param closingTime
     * @param openingTime
     * @param timeZone
     */
    public OperatingHours(OperatingHours.DayOfWeek dayOfWeek, String openingTime, String closingTime, String timeZone) {
        super();
        this.dayOfWeek = dayOfWeek;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.timeZone = timeZone;
    }

    /**
     * The days of the week with the addition of a special HOLIDAY element
     * (Required)
     * 
     */
    @JsonProperty("dayOfWeek")
    public OperatingHours.DayOfWeek getDayOfWeek() {
        return dayOfWeek;
    }

    /**
     * The days of the week with the addition of a special HOLIDAY element
     * (Required)
     * 
     */
    @JsonProperty("dayOfWeek")
    public void setDayOfWeek(OperatingHours.DayOfWeek dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    /**
     * The opening time of the location in ISO 8601 time of day format
     * (Required)
     * 
     */
    @JsonProperty("openingTime")
    public String getOpeningTime() {
        return openingTime;
    }

    /**
     * The opening time of the location in ISO 8601 time of day format
     * (Required)
     * 
     */
    @JsonProperty("openingTime")
    public void setOpeningTime(String openingTime) {
        this.openingTime = openingTime;
    }

    /**
     * The closing time of the location in ISO 8601 time of day format
     * (Required)
     * 
     */
    @JsonProperty("closingTime")
    public String getClosingTime() {
        return closingTime;
    }

    /**
     * The closing time of the location in ISO 8601 time of day format
     * (Required)
     * 
     */
    @JsonProperty("closingTime")
    public void setClosingTime(String closingTime) {
        this.closingTime = closingTime;
    }

    /**
     * The tz database name for this location's time zone
     * 
     */
    @JsonProperty("timeZone")
    public Optional<String> getTimeZone() {
        return Optional.ofNullable(timeZone);
    }

    /**
     * The tz database name for this location's time zone
     * 
     */
    @JsonProperty("timeZone")
    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(OperatingHours.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("dayOfWeek");
        sb.append('=');
        sb.append(((this.dayOfWeek == null)?"<null>":this.dayOfWeek));
        sb.append(',');
        sb.append("openingTime");
        sb.append('=');
        sb.append(((this.openingTime == null)?"<null>":this.openingTime));
        sb.append(',');
        sb.append("closingTime");
        sb.append('=');
        sb.append(((this.closingTime == null)?"<null>":this.closingTime));
        sb.append(',');
        sb.append("timeZone");
        sb.append('=');
        sb.append(((this.timeZone == null)?"<null>":this.timeZone));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.timeZone == null)? 0 :this.timeZone.hashCode()));
        result = ((result* 31)+((this.dayOfWeek == null)? 0 :this.dayOfWeek.hashCode()));
        result = ((result* 31)+((this.closingTime == null)? 0 :this.closingTime.hashCode()));
        result = ((result* 31)+((this.openingTime == null)? 0 :this.openingTime.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OperatingHours) == false) {
            return false;
        }
        OperatingHours rhs = ((OperatingHours) other);
        return (((((this.timeZone == rhs.timeZone)||((this.timeZone!= null)&&this.timeZone.equals(rhs.timeZone)))&&((this.dayOfWeek == rhs.dayOfWeek)||((this.dayOfWeek!= null)&&this.dayOfWeek.equals(rhs.dayOfWeek))))&&((this.closingTime == rhs.closingTime)||((this.closingTime!= null)&&this.closingTime.equals(rhs.closingTime))))&&((this.openingTime == rhs.openingTime)||((this.openingTime!= null)&&this.openingTime.equals(rhs.openingTime))));
    }


    /**
     * The days of the week with the addition of a special HOLIDAY element
     * 
     */
    public enum DayOfWeek {

        MONDAY("MONDAY"),
        TUESDAY("TUESDAY"),
        WEDNESDAY("WEDNESDAY"),
        THURSDAY("THURSDAY"),
        FRIDAY("FRIDAY"),
        SATURDAY("SATURDAY"),
        SUNDAY("SUNDAY"),
        HOLIDAY("HOLIDAY");
        private final String value;
        private final static Map<String, OperatingHours.DayOfWeek> CONSTANTS = new HashMap<String, OperatingHours.DayOfWeek>();

        static {
            for (OperatingHours.DayOfWeek c: values()) {
                CONSTANTS.put(c.value, c);
            }
        }

        private DayOfWeek(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return this.value;
        }

        @JsonValue
        public String value() {
            return this.value;
        }

        @JsonCreator
        public static OperatingHours.DayOfWeek fromValue(String value) {
            OperatingHours.DayOfWeek constant = CONSTANTS.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

    }

    public static class OperatingHoursBuilder<T extends OperatingHours >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public OperatingHoursBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(OperatingHours.OperatingHoursBuilder.class)) {
                this.instance = ((T) new OperatingHours());
            }
        }

        @SuppressWarnings("unchecked")
        public OperatingHoursBuilder(OperatingHours.DayOfWeek dayOfWeek, String openingTime, String closingTime, String timeZone) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(OperatingHours.OperatingHoursBuilder.class)) {
                this.instance = ((T) new OperatingHours(dayOfWeek, openingTime, closingTime, timeZone));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public OperatingHours.OperatingHoursBuilder withDayOfWeek(OperatingHours.DayOfWeek dayOfWeek) {
            ((OperatingHours) this.instance).dayOfWeek = dayOfWeek;
            return this;
        }

        public OperatingHours.OperatingHoursBuilder withOpeningTime(String openingTime) {
            ((OperatingHours) this.instance).openingTime = openingTime;
            return this;
        }

        public OperatingHours.OperatingHoursBuilder withClosingTime(String closingTime) {
            ((OperatingHours) this.instance).closingTime = closingTime;
            return this;
        }

        public OperatingHours.OperatingHoursBuilder withTimeZone(String timeZone) {
            ((OperatingHours) this.instance).timeZone = timeZone;
            return this;
        }

    }

}

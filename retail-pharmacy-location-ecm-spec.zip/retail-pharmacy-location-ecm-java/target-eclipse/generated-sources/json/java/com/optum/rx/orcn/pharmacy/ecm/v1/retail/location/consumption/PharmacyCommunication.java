
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption;

import java.util.Optional;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * pharmacyCommunication
 * <p>
 * 
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "telephoneNumber",
    "telephoneNumberExtn",
    "emergencyTelephoneNumber",
    "emergencyTelephoneNumberExtn",
    "faxTelephoneNumber",
    "contactEmail"
})
public class PharmacyCommunication {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("telephoneNumber")
    @NotNull
    private String telephoneNumber;
    @JsonProperty("telephoneNumberExtn")
    private String telephoneNumberExtn;
    @JsonProperty("emergencyTelephoneNumber")
    private String emergencyTelephoneNumber;
    @JsonProperty("emergencyTelephoneNumberExtn")
    private String emergencyTelephoneNumberExtn;
    @JsonProperty("faxTelephoneNumber")
    private String faxTelephoneNumber;
    @JsonProperty("contactEmail")
    private String contactEmail;

    /**
     * No args constructor for use in serialization
     * 
     */
    public PharmacyCommunication() {
    }

    /**
     * 
     * @param telephoneNumberExtn
     * @param emergencyTelephoneNumberExtn
     * @param telephoneNumber
     * @param contactEmail
     * @param emergencyTelephoneNumber
     * @param faxTelephoneNumber
     */
    public PharmacyCommunication(String telephoneNumber, String telephoneNumberExtn, String emergencyTelephoneNumber, String emergencyTelephoneNumberExtn, String faxTelephoneNumber, String contactEmail) {
        super();
        this.telephoneNumber = telephoneNumber;
        this.telephoneNumberExtn = telephoneNumberExtn;
        this.emergencyTelephoneNumber = emergencyTelephoneNumber;
        this.emergencyTelephoneNumberExtn = emergencyTelephoneNumberExtn;
        this.faxTelephoneNumber = faxTelephoneNumber;
        this.contactEmail = contactEmail;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("telephoneNumber")
    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("telephoneNumber")
    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    @JsonProperty("telephoneNumberExtn")
    public Optional<String> getTelephoneNumberExtn() {
        return Optional.ofNullable(telephoneNumberExtn);
    }

    @JsonProperty("telephoneNumberExtn")
    public void setTelephoneNumberExtn(String telephoneNumberExtn) {
        this.telephoneNumberExtn = telephoneNumberExtn;
    }

    @JsonProperty("emergencyTelephoneNumber")
    public Optional<String> getEmergencyTelephoneNumber() {
        return Optional.ofNullable(emergencyTelephoneNumber);
    }

    @JsonProperty("emergencyTelephoneNumber")
    public void setEmergencyTelephoneNumber(String emergencyTelephoneNumber) {
        this.emergencyTelephoneNumber = emergencyTelephoneNumber;
    }

    @JsonProperty("emergencyTelephoneNumberExtn")
    public Optional<String> getEmergencyTelephoneNumberExtn() {
        return Optional.ofNullable(emergencyTelephoneNumberExtn);
    }

    @JsonProperty("emergencyTelephoneNumberExtn")
    public void setEmergencyTelephoneNumberExtn(String emergencyTelephoneNumberExtn) {
        this.emergencyTelephoneNumberExtn = emergencyTelephoneNumberExtn;
    }

    @JsonProperty("faxTelephoneNumber")
    public Optional<String> getFaxTelephoneNumber() {
        return Optional.ofNullable(faxTelephoneNumber);
    }

    @JsonProperty("faxTelephoneNumber")
    public void setFaxTelephoneNumber(String faxTelephoneNumber) {
        this.faxTelephoneNumber = faxTelephoneNumber;
    }

    @JsonProperty("contactEmail")
    public Optional<String> getContactEmail() {
        return Optional.ofNullable(contactEmail);
    }

    @JsonProperty("contactEmail")
    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PharmacyCommunication.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("telephoneNumber");
        sb.append('=');
        sb.append(((this.telephoneNumber == null)?"<null>":this.telephoneNumber));
        sb.append(',');
        sb.append("telephoneNumberExtn");
        sb.append('=');
        sb.append(((this.telephoneNumberExtn == null)?"<null>":this.telephoneNumberExtn));
        sb.append(',');
        sb.append("emergencyTelephoneNumber");
        sb.append('=');
        sb.append(((this.emergencyTelephoneNumber == null)?"<null>":this.emergencyTelephoneNumber));
        sb.append(',');
        sb.append("emergencyTelephoneNumberExtn");
        sb.append('=');
        sb.append(((this.emergencyTelephoneNumberExtn == null)?"<null>":this.emergencyTelephoneNumberExtn));
        sb.append(',');
        sb.append("faxTelephoneNumber");
        sb.append('=');
        sb.append(((this.faxTelephoneNumber == null)?"<null>":this.faxTelephoneNumber));
        sb.append(',');
        sb.append("contactEmail");
        sb.append('=');
        sb.append(((this.contactEmail == null)?"<null>":this.contactEmail));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.telephoneNumberExtn == null)? 0 :this.telephoneNumberExtn.hashCode()));
        result = ((result* 31)+((this.emergencyTelephoneNumberExtn == null)? 0 :this.emergencyTelephoneNumberExtn.hashCode()));
        result = ((result* 31)+((this.telephoneNumber == null)? 0 :this.telephoneNumber.hashCode()));
        result = ((result* 31)+((this.contactEmail == null)? 0 :this.contactEmail.hashCode()));
        result = ((result* 31)+((this.emergencyTelephoneNumber == null)? 0 :this.emergencyTelephoneNumber.hashCode()));
        result = ((result* 31)+((this.faxTelephoneNumber == null)? 0 :this.faxTelephoneNumber.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PharmacyCommunication) == false) {
            return false;
        }
        PharmacyCommunication rhs = ((PharmacyCommunication) other);
        return (((((((this.telephoneNumberExtn == rhs.telephoneNumberExtn)||((this.telephoneNumberExtn!= null)&&this.telephoneNumberExtn.equals(rhs.telephoneNumberExtn)))&&((this.emergencyTelephoneNumberExtn == rhs.emergencyTelephoneNumberExtn)||((this.emergencyTelephoneNumberExtn!= null)&&this.emergencyTelephoneNumberExtn.equals(rhs.emergencyTelephoneNumberExtn))))&&((this.telephoneNumber == rhs.telephoneNumber)||((this.telephoneNumber!= null)&&this.telephoneNumber.equals(rhs.telephoneNumber))))&&((this.contactEmail == rhs.contactEmail)||((this.contactEmail!= null)&&this.contactEmail.equals(rhs.contactEmail))))&&((this.emergencyTelephoneNumber == rhs.emergencyTelephoneNumber)||((this.emergencyTelephoneNumber!= null)&&this.emergencyTelephoneNumber.equals(rhs.emergencyTelephoneNumber))))&&((this.faxTelephoneNumber == rhs.faxTelephoneNumber)||((this.faxTelephoneNumber!= null)&&this.faxTelephoneNumber.equals(rhs.faxTelephoneNumber))));
    }

    public static class PharmacyCommunicationBuilder<T extends PharmacyCommunication >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public PharmacyCommunicationBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyCommunication.PharmacyCommunicationBuilder.class)) {
                this.instance = ((T) new PharmacyCommunication());
            }
        }

        @SuppressWarnings("unchecked")
        public PharmacyCommunicationBuilder(String telephoneNumber, String telephoneNumberExtn, String emergencyTelephoneNumber, String emergencyTelephoneNumberExtn, String faxTelephoneNumber, String contactEmail) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyCommunication.PharmacyCommunicationBuilder.class)) {
                this.instance = ((T) new PharmacyCommunication(telephoneNumber, telephoneNumberExtn, emergencyTelephoneNumber, emergencyTelephoneNumberExtn, faxTelephoneNumber, contactEmail));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public PharmacyCommunication.PharmacyCommunicationBuilder withTelephoneNumber(String telephoneNumber) {
            ((PharmacyCommunication) this.instance).telephoneNumber = telephoneNumber;
            return this;
        }

        public PharmacyCommunication.PharmacyCommunicationBuilder withTelephoneNumberExtn(String telephoneNumberExtn) {
            ((PharmacyCommunication) this.instance).telephoneNumberExtn = telephoneNumberExtn;
            return this;
        }

        public PharmacyCommunication.PharmacyCommunicationBuilder withEmergencyTelephoneNumber(String emergencyTelephoneNumber) {
            ((PharmacyCommunication) this.instance).emergencyTelephoneNumber = emergencyTelephoneNumber;
            return this;
        }

        public PharmacyCommunication.PharmacyCommunicationBuilder withEmergencyTelephoneNumberExtn(String emergencyTelephoneNumberExtn) {
            ((PharmacyCommunication) this.instance).emergencyTelephoneNumberExtn = emergencyTelephoneNumberExtn;
            return this;
        }

        public PharmacyCommunication.PharmacyCommunicationBuilder withFaxTelephoneNumber(String faxTelephoneNumber) {
            ((PharmacyCommunication) this.instance).faxTelephoneNumber = faxTelephoneNumber;
            return this;
        }

        public PharmacyCommunication.PharmacyCommunicationBuilder withContactEmail(String contactEmail) {
            ((PharmacyCommunication) this.instance).contactEmail = contactEmail;
            return this;
        }

    }

}

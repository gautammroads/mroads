
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption;

import java.util.Optional;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * pharmacyInformation
 * <p>
 * 
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "pharmacyId",
    "retailer",
    "location"
})
public class PharmacyInformation {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("pharmacyId")
    @NotNull
    private String pharmacyId;
    /**
     * retailer
     * <p>
     * 
     * 
     */
    @JsonProperty("retailer")
    @Valid
    private Retailer retailer;
    /**
     * retailPharmacyLocation
     * <p>
     * 
     * 
     */
    @JsonProperty("location")
    @Valid
    private RetailPharmacyLocation location;

    /**
     * No args constructor for use in serialization
     * 
     */
    public PharmacyInformation() {
    }

    /**
     * 
     * @param pharmacyId
     * @param retailer
     * @param location
     */
    public PharmacyInformation(String pharmacyId, Retailer retailer, RetailPharmacyLocation location) {
        super();
        this.pharmacyId = pharmacyId;
        this.retailer = retailer;
        this.location = location;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("pharmacyId")
    public String getPharmacyId() {
        return pharmacyId;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("pharmacyId")
    public void setPharmacyId(String pharmacyId) {
        this.pharmacyId = pharmacyId;
    }

    /**
     * retailer
     * <p>
     * 
     * 
     */
    @JsonProperty("retailer")
    public Optional<Retailer> getRetailer() {
        return Optional.ofNullable(retailer);
    }

    /**
     * retailer
     * <p>
     * 
     * 
     */
    @JsonProperty("retailer")
    public void setRetailer(Retailer retailer) {
        this.retailer = retailer;
    }

    /**
     * retailPharmacyLocation
     * <p>
     * 
     * 
     */
    @JsonProperty("location")
    public Optional<RetailPharmacyLocation> getLocation() {
        return Optional.ofNullable(location);
    }

    /**
     * retailPharmacyLocation
     * <p>
     * 
     * 
     */
    @JsonProperty("location")
    public void setLocation(RetailPharmacyLocation location) {
        this.location = location;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PharmacyInformation.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("pharmacyId");
        sb.append('=');
        sb.append(((this.pharmacyId == null)?"<null>":this.pharmacyId));
        sb.append(',');
        sb.append("retailer");
        sb.append('=');
        sb.append(((this.retailer == null)?"<null>":this.retailer));
        sb.append(',');
        sb.append("location");
        sb.append('=');
        sb.append(((this.location == null)?"<null>":this.location));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.pharmacyId == null)? 0 :this.pharmacyId.hashCode()));
        result = ((result* 31)+((this.location == null)? 0 :this.location.hashCode()));
        result = ((result* 31)+((this.retailer == null)? 0 :this.retailer.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PharmacyInformation) == false) {
            return false;
        }
        PharmacyInformation rhs = ((PharmacyInformation) other);
        return ((((this.pharmacyId == rhs.pharmacyId)||((this.pharmacyId!= null)&&this.pharmacyId.equals(rhs.pharmacyId)))&&((this.location == rhs.location)||((this.location!= null)&&this.location.equals(rhs.location))))&&((this.retailer == rhs.retailer)||((this.retailer!= null)&&this.retailer.equals(rhs.retailer))));
    }

    public static class PharmacyInformationBuilder<T extends PharmacyInformation >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public PharmacyInformationBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyInformation.PharmacyInformationBuilder.class)) {
                this.instance = ((T) new PharmacyInformation());
            }
        }

        @SuppressWarnings("unchecked")
        public PharmacyInformationBuilder(String pharmacyId, Retailer retailer, RetailPharmacyLocation location) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyInformation.PharmacyInformationBuilder.class)) {
                this.instance = ((T) new PharmacyInformation(pharmacyId, retailer, location));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public PharmacyInformation.PharmacyInformationBuilder withPharmacyId(String pharmacyId) {
            ((PharmacyInformation) this.instance).pharmacyId = pharmacyId;
            return this;
        }

        public PharmacyInformation.PharmacyInformationBuilder withRetailer(Retailer retailer) {
            ((PharmacyInformation) this.instance).retailer = retailer;
            return this;
        }

        public PharmacyInformation.PharmacyInformationBuilder withLocation(RetailPharmacyLocation location) {
            ((PharmacyInformation) this.instance).location = location;
            return this;
        }

    }

}

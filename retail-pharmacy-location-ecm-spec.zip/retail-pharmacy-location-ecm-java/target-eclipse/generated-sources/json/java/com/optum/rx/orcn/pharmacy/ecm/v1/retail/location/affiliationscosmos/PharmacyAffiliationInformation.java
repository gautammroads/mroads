
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.affiliationscosmos;

import java.net.URI;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "affiliationId",
    "affiliationName",
    "sourceSystemCode",
    "sourceSystemInstance",
    "membershipRequired",
    "membershipDetailsUrl",
    "logoImageUrl",
    "darkModeImageUrl"
})
public class PharmacyAffiliationInformation {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("affiliationId")
    @NotNull
    private String affiliationId;
    @JsonProperty("affiliationName")
    private String affiliationName;
    @JsonProperty("sourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("sourceSystemInstance")
    private String sourceSystemInstance;
    @JsonProperty("membershipRequired")
    private boolean membershipRequired;
    @JsonProperty("membershipDetailsUrl")
    private URI membershipDetailsUrl;
    @JsonProperty("logoImageUrl")
    private URI logoImageUrl;
    @JsonProperty("darkModeImageUrl")
    private URI darkModeImageUrl;

    /**
     * No args constructor for use in serialization
     * 
     */
    public PharmacyAffiliationInformation() {
    }

    /**
     * 
     * @param membershipRequired
     * @param affiliationName
     * @param darkModeImageUrl
     * @param membershipDetailsUrl
     * @param affiliationId
     * @param sourceSystemCode
     * @param sourceSystemInstance
     * @param logoImageUrl
     */
    public PharmacyAffiliationInformation(String affiliationId, String affiliationName, String sourceSystemCode, String sourceSystemInstance, boolean membershipRequired, URI membershipDetailsUrl, URI logoImageUrl, URI darkModeImageUrl) {
        super();
        this.affiliationId = affiliationId;
        this.affiliationName = affiliationName;
        this.sourceSystemCode = sourceSystemCode;
        this.sourceSystemInstance = sourceSystemInstance;
        this.membershipRequired = membershipRequired;
        this.membershipDetailsUrl = membershipDetailsUrl;
        this.logoImageUrl = logoImageUrl;
        this.darkModeImageUrl = darkModeImageUrl;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("affiliationId")
    public String getAffiliationId() {
        return affiliationId;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("affiliationId")
    public void setAffiliationId(String affiliationId) {
        this.affiliationId = affiliationId;
    }

    @JsonProperty("affiliationName")
    public Optional<String> getAffiliationName() {
        return Optional.ofNullable(affiliationName);
    }

    @JsonProperty("affiliationName")
    public void setAffiliationName(String affiliationName) {
        this.affiliationName = affiliationName;
    }

    @JsonProperty("sourceSystemCode")
    public Optional<String> getSourceSystemCode() {
        return Optional.ofNullable(sourceSystemCode);
    }

    @JsonProperty("sourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    @JsonProperty("sourceSystemInstance")
    public Optional<String> getSourceSystemInstance() {
        return Optional.ofNullable(sourceSystemInstance);
    }

    @JsonProperty("sourceSystemInstance")
    public void setSourceSystemInstance(String sourceSystemInstance) {
        this.sourceSystemInstance = sourceSystemInstance;
    }

    @JsonProperty("membershipRequired")
    public boolean isMembershipRequired() {
        return membershipRequired;
    }

    @JsonProperty("membershipRequired")
    public void setMembershipRequired(boolean membershipRequired) {
        this.membershipRequired = membershipRequired;
    }

    @JsonProperty("membershipDetailsUrl")
    public Optional<URI> getMembershipDetailsUrl() {
        return Optional.ofNullable(membershipDetailsUrl);
    }

    @JsonProperty("membershipDetailsUrl")
    public void setMembershipDetailsUrl(URI membershipDetailsUrl) {
        this.membershipDetailsUrl = membershipDetailsUrl;
    }

    @JsonProperty("logoImageUrl")
    public Optional<URI> getLogoImageUrl() {
        return Optional.ofNullable(logoImageUrl);
    }

    @JsonProperty("logoImageUrl")
    public void setLogoImageUrl(URI logoImageUrl) {
        this.logoImageUrl = logoImageUrl;
    }

    @JsonProperty("darkModeImageUrl")
    public Optional<URI> getDarkModeImageUrl() {
        return Optional.ofNullable(darkModeImageUrl);
    }

    @JsonProperty("darkModeImageUrl")
    public void setDarkModeImageUrl(URI darkModeImageUrl) {
        this.darkModeImageUrl = darkModeImageUrl;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PharmacyAffiliationInformation.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("affiliationId");
        sb.append('=');
        sb.append(((this.affiliationId == null)?"<null>":this.affiliationId));
        sb.append(',');
        sb.append("affiliationName");
        sb.append('=');
        sb.append(((this.affiliationName == null)?"<null>":this.affiliationName));
        sb.append(',');
        sb.append("sourceSystemCode");
        sb.append('=');
        sb.append(((this.sourceSystemCode == null)?"<null>":this.sourceSystemCode));
        sb.append(',');
        sb.append("sourceSystemInstance");
        sb.append('=');
        sb.append(((this.sourceSystemInstance == null)?"<null>":this.sourceSystemInstance));
        sb.append(',');
        sb.append("membershipRequired");
        sb.append('=');
        sb.append(this.membershipRequired);
        sb.append(',');
        sb.append("membershipDetailsUrl");
        sb.append('=');
        sb.append(((this.membershipDetailsUrl == null)?"<null>":this.membershipDetailsUrl));
        sb.append(',');
        sb.append("logoImageUrl");
        sb.append('=');
        sb.append(((this.logoImageUrl == null)?"<null>":this.logoImageUrl));
        sb.append(',');
        sb.append("darkModeImageUrl");
        sb.append('=');
        sb.append(((this.darkModeImageUrl == null)?"<null>":this.darkModeImageUrl));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+(this.membershipRequired? 1 : 0));
        result = ((result* 31)+((this.affiliationName == null)? 0 :this.affiliationName.hashCode()));
        result = ((result* 31)+((this.darkModeImageUrl == null)? 0 :this.darkModeImageUrl.hashCode()));
        result = ((result* 31)+((this.membershipDetailsUrl == null)? 0 :this.membershipDetailsUrl.hashCode()));
        result = ((result* 31)+((this.affiliationId == null)? 0 :this.affiliationId.hashCode()));
        result = ((result* 31)+((this.sourceSystemCode == null)? 0 :this.sourceSystemCode.hashCode()));
        result = ((result* 31)+((this.sourceSystemInstance == null)? 0 :this.sourceSystemInstance.hashCode()));
        result = ((result* 31)+((this.logoImageUrl == null)? 0 :this.logoImageUrl.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PharmacyAffiliationInformation) == false) {
            return false;
        }
        PharmacyAffiliationInformation rhs = ((PharmacyAffiliationInformation) other);
        return ((((((((this.membershipRequired == rhs.membershipRequired)&&((this.affiliationName == rhs.affiliationName)||((this.affiliationName!= null)&&this.affiliationName.equals(rhs.affiliationName))))&&((this.darkModeImageUrl == rhs.darkModeImageUrl)||((this.darkModeImageUrl!= null)&&this.darkModeImageUrl.equals(rhs.darkModeImageUrl))))&&((this.membershipDetailsUrl == rhs.membershipDetailsUrl)||((this.membershipDetailsUrl!= null)&&this.membershipDetailsUrl.equals(rhs.membershipDetailsUrl))))&&((this.affiliationId == rhs.affiliationId)||((this.affiliationId!= null)&&this.affiliationId.equals(rhs.affiliationId))))&&((this.sourceSystemCode == rhs.sourceSystemCode)||((this.sourceSystemCode!= null)&&this.sourceSystemCode.equals(rhs.sourceSystemCode))))&&((this.sourceSystemInstance == rhs.sourceSystemInstance)||((this.sourceSystemInstance!= null)&&this.sourceSystemInstance.equals(rhs.sourceSystemInstance))))&&((this.logoImageUrl == rhs.logoImageUrl)||((this.logoImageUrl!= null)&&this.logoImageUrl.equals(rhs.logoImageUrl))));
    }

    public static class PharmacyAffiliationInformationBuilder<T extends PharmacyAffiliationInformation >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public PharmacyAffiliationInformationBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder.class)) {
                this.instance = ((T) new PharmacyAffiliationInformation());
            }
        }

        @SuppressWarnings("unchecked")
        public PharmacyAffiliationInformationBuilder(String affiliationId, String affiliationName, String sourceSystemCode, String sourceSystemInstance, boolean membershipRequired, URI membershipDetailsUrl, URI logoImageUrl, URI darkModeImageUrl) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder.class)) {
                this.instance = ((T) new PharmacyAffiliationInformation(affiliationId, affiliationName, sourceSystemCode, sourceSystemInstance, membershipRequired, membershipDetailsUrl, logoImageUrl, darkModeImageUrl));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withAffiliationId(String affiliationId) {
            ((PharmacyAffiliationInformation) this.instance).affiliationId = affiliationId;
            return this;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withAffiliationName(String affiliationName) {
            ((PharmacyAffiliationInformation) this.instance).affiliationName = affiliationName;
            return this;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withSourceSystemCode(String sourceSystemCode) {
            ((PharmacyAffiliationInformation) this.instance).sourceSystemCode = sourceSystemCode;
            return this;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withSourceSystemInstance(String sourceSystemInstance) {
            ((PharmacyAffiliationInformation) this.instance).sourceSystemInstance = sourceSystemInstance;
            return this;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withMembershipRequired(boolean membershipRequired) {
            ((PharmacyAffiliationInformation) this.instance).membershipRequired = membershipRequired;
            return this;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withMembershipDetailsUrl(URI membershipDetailsUrl) {
            ((PharmacyAffiliationInformation) this.instance).membershipDetailsUrl = membershipDetailsUrl;
            return this;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withLogoImageUrl(URI logoImageUrl) {
            ((PharmacyAffiliationInformation) this.instance).logoImageUrl = logoImageUrl;
            return this;
        }

        public PharmacyAffiliationInformation.PharmacyAffiliationInformationBuilder withDarkModeImageUrl(URI darkModeImageUrl) {
            ((PharmacyAffiliationInformation) this.instance).darkModeImageUrl = darkModeImageUrl;
            return this;
        }

    }

}

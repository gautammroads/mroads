
package com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.cosmos;

import java.util.Optional;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dayOfWeek",
    "timeZone",
    "startTime",
    "endTime"
})
public class Schedule {

    @JsonProperty("dayOfWeek")
    private String dayOfWeek;
    @JsonProperty("timeZone")
    private String timeZone;
    @JsonProperty("startTime")
    private String startTime;
    @JsonProperty("endTime")
    private String endTime;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Schedule() {
    }

    /**
     * 
     * @param dayOfWeek
     * @param timeZone
     * @param startTime
     * @param endTime
     */
    public Schedule(String dayOfWeek, String timeZone, String startTime, String endTime) {
        super();
        this.dayOfWeek = dayOfWeek;
        this.timeZone = timeZone;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    @JsonProperty("dayOfWeek")
    public Optional<String> getDayOfWeek() {
        return Optional.ofNullable(dayOfWeek);
    }

    @JsonProperty("dayOfWeek")
    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    @JsonProperty("timeZone")
    public Optional<String> getTimeZone() {
        return Optional.ofNullable(timeZone);
    }

    @JsonProperty("timeZone")
    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    @JsonProperty("startTime")
    public Optional<String> getStartTime() {
        return Optional.ofNullable(startTime);
    }

    @JsonProperty("startTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    @JsonProperty("endTime")
    public Optional<String> getEndTime() {
        return Optional.ofNullable(endTime);
    }

    @JsonProperty("endTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Schedule.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("dayOfWeek");
        sb.append('=');
        sb.append(((this.dayOfWeek == null)?"<null>":this.dayOfWeek));
        sb.append(',');
        sb.append("timeZone");
        sb.append('=');
        sb.append(((this.timeZone == null)?"<null>":this.timeZone));
        sb.append(',');
        sb.append("startTime");
        sb.append('=');
        sb.append(((this.startTime == null)?"<null>":this.startTime));
        sb.append(',');
        sb.append("endTime");
        sb.append('=');
        sb.append(((this.endTime == null)?"<null>":this.endTime));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.timeZone == null)? 0 :this.timeZone.hashCode()));
        result = ((result* 31)+((this.startTime == null)? 0 :this.startTime.hashCode()));
        result = ((result* 31)+((this.dayOfWeek == null)? 0 :this.dayOfWeek.hashCode()));
        result = ((result* 31)+((this.endTime == null)? 0 :this.endTime.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Schedule) == false) {
            return false;
        }
        Schedule rhs = ((Schedule) other);
        return (((((this.timeZone == rhs.timeZone)||((this.timeZone!= null)&&this.timeZone.equals(rhs.timeZone)))&&((this.startTime == rhs.startTime)||((this.startTime!= null)&&this.startTime.equals(rhs.startTime))))&&((this.dayOfWeek == rhs.dayOfWeek)||((this.dayOfWeek!= null)&&this.dayOfWeek.equals(rhs.dayOfWeek))))&&((this.endTime == rhs.endTime)||((this.endTime!= null)&&this.endTime.equals(rhs.endTime))));
    }

    public static class ScheduleBuilder<T extends Schedule >{

        protected T instance;

        @SuppressWarnings("unchecked")
        public ScheduleBuilder() {
            // Skip initialization when called from subclass
            if (this.getClass().equals(Schedule.ScheduleBuilder.class)) {
                this.instance = ((T) new Schedule());
            }
        }

        @SuppressWarnings("unchecked")
        public ScheduleBuilder(String dayOfWeek, String timeZone, String startTime, String endTime) {
            // Skip initialization when called from subclass
            if (this.getClass().equals(Schedule.ScheduleBuilder.class)) {
                this.instance = ((T) new Schedule(dayOfWeek, timeZone, startTime, endTime));
            }
        }

        public T build() {
            T result;
            result = this.instance;
            this.instance = null;
            return result;
        }

        public Schedule.ScheduleBuilder withDayOfWeek(String dayOfWeek) {
            ((Schedule) this.instance).dayOfWeek = dayOfWeek;
            return this;
        }

        public Schedule.ScheduleBuilder withTimeZone(String timeZone) {
            ((Schedule) this.instance).timeZone = timeZone;
            return this;
        }

        public Schedule.ScheduleBuilder withStartTime(String startTime) {
            ((Schedule) this.instance).startTime = startTime;
            return this;
        }

        public Schedule.ScheduleBuilder withEndTime(String endTime) {
            ((Schedule) this.instance).endTime = endTime;
            return this;
        }

    }

}

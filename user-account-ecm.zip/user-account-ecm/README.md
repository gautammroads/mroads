# user-account-ecm-java

## Purpose

This project contains the POM file needed to build the Java pojos from the JSON schema, ingested by the Maven plugins.

A snapshot jar containing the Java pojo class files will be pushed to Artifactory under the correct groupId and artifactId.

Generated source files are also located in /target/generated-sources/json.

The JSON schema represents the /components/schema/User account, found in the Swagger specification issued by LiveFront for the Optum Perks front-end.

The original Swagger specification is produced under version numbers. Currently, version 40 is the latest. Therefore, generated Java objects from this schema will have the following package name:

```bash
com.optum.rx.orcn.user.account
```

## See related project:

user-account-ecm-spec



kubectl create ns cloud-api
helm install user-account-ms . --namespace cloud-api
kubectl expose deploy user-account-ms --type=LoadBalancer --name=external-svc --namespace=cloud-api

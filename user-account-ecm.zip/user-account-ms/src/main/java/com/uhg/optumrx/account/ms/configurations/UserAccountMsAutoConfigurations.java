package com.uhg.optumrx.account.ms.configurations;

import org.springdoc.core.SpringDocConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.context.ConfigurationPropertiesAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import com.uhg.optumrx.account.ms.UserAccountMsApplicationProperties;
import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;

@UtilityClass
public class UserAccountMsAutoConfigurations {

    @Configuration
    @AutoConfigureAfter({ ConfigurationPropertiesAutoConfiguration.class, SpringDocConfiguration.class,
            SpringDocConfiguration.class })
    @Value
    @NonFinal
    @Accessors(fluent = true)
    public static class UserAccountApplicationPropertiesAutoConfiguration {


        @Bean
        @ConfigurationProperties("user-account-ms")
        @NonNull
        public UserAccountMsApplicationProperties userAccountMsApplicationProperties() {
            return new UserAccountMsApplicationProperties();

        }
        
       
    }

}

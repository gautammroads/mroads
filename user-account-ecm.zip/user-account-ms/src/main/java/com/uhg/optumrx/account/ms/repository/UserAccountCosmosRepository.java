package com.uhg.optumrx.account.ms.repository;

import org.springframework.stereotype.Repository;
import com.microsoft.azure.spring.data.cosmosdb.repository.CosmosRepository;
import com.uhg.optumrx.account.ms.entity.UserAccountEntity;

@Repository
public interface UserAccountCosmosRepository extends CosmosRepository<UserAccountEntity,String > {

}

package com.uhg.optumrx.account.ms.entity;



import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "page",
    "limit",
    "pageContinuationToken"
})
public class Metadata {

    @JsonProperty("page")
    private double page;
    @JsonProperty("limit")
    private double limit;
    /**
     * This pagination token is passed back and forth to retrieve the next page(optional).
     * 
     */
    @JsonProperty("pageContinuationToken")
    @JsonPropertyDescription("This pagination token is passed back and forth to retrieve the next page(optional).")
    private String pageContinuationToken;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Metadata() {
    }

    /**
     * 
     * @param limit
     * @param pageContinuationToken
     * @param page
     */
    public Metadata(double page, double limit, String pageContinuationToken) {
        super();
        this.page = page;
        this.limit = limit;
        this.pageContinuationToken = pageContinuationToken;
    }

    @JsonProperty("page")
    public double getPage() {
        return page;
    }

    @JsonProperty("page")
    public void setPage(double page) {
        this.page = page;
    }

    @JsonProperty("limit")
    public double getLimit() {
        return limit;
    }

    @JsonProperty("limit")
    public void setLimit(double limit) {
        this.limit = limit;
    }

    /**
     * This pagination token is passed back and forth to retrieve the next page(optional).
     * 
     */
    @JsonProperty("pageContinuationToken")
    public Optional<String> getPageContinuationToken() {
        return Optional.ofNullable(pageContinuationToken);
    }

    /**
     * This pagination token is passed back and forth to retrieve the next page(optional).
     * 
     */
    @JsonProperty("pageContinuationToken")
    public void setPageContinuationToken(String pageContinuationToken) {
        this.pageContinuationToken = pageContinuationToken;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

  

}

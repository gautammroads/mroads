package com.uhg.optumrx.account.ms.configurations;


import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Configuration;

import com.microsoft.azure.spring.autoconfigure.cosmosdb.CosmosAutoConfiguration;
import com.microsoft.azure.spring.autoconfigure.cosmosdb.CosmosDbRepositoriesAutoConfiguration;

import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;



@UtilityClass
public class UserAccountCosmosAutoConfigurations {


    @Configuration
    @AutoConfigureAfter({ CosmosAutoConfiguration.class, CosmosDbRepositoriesAutoConfiguration.class})
    @Value
    @NonFinal
    @Accessors(fluent = true)
    public static class UserAccountCosmosRepositoryAutoConfiguration {
    	
    	 
    }
}

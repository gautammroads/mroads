package com.uhg.optumrx.account.ms;

import static java.util.Optional.*;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class UserAccountMsApplicationProperties {

	/**
	 * The root view name to map calls to <code>'/'</code>
	 */
	String rootContextViewControllerViewName;

	/**
	 * The root view name to map calls to <code>'/'</code>
	 */
	String rootRedirectViewUrl;
	
	
	String retailPharmacyLocationSearchUrl;
	

	/**
	 * Root context view controller view name.
	 *
	 * @return the rootContextViewControllerViewName or empty
	 */
	public Optional<String> rootRedirectViewUrl() {
		return ofNullable(this.rootRedirectViewUrl);
	}

	/**
	 * Root context view controller view name.
	 *
	 * @return the rootContextViewControllerViewName or empty
	 */
	public Optional<String> rootContextViewControllerViewName() {
		return ofNullable(this.rootContextViewControllerViewName);
	}
	
	public Optional<String> retailPharmacyLocationSearchUrl() {
		return ofNullable(this.retailPharmacyLocationSearchUrl);
	}
}

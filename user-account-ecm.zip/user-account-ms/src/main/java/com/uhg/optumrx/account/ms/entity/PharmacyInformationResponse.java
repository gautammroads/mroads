package com.uhg.optumrx.account.ms.entity;


import com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption.PharmacyInformation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PharmacyInformationResponse {
    private List<PharmacyInformation> data;
    private ResponseMetadata metadata;

}

package com.uhg.optumrx.account.ms.configurations;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;

@UtilityClass
public class UserAccountWebMvcConfigurers {

    /**
     * Maps root to the supplied viewname
     */
    @Value
    @NonFinal
    @Accessors(fluent = true)
    public static class RootContextWebMvcConfigurer extends AcceptHeaderLocaleResolver implements WebMvcConfigurer {

        @NonNull
        final String rootControllerViewName;

        @Override
        public void addViewControllers(final ViewControllerRegistry viewControllerRegistry) {
            viewControllerRegistry.addViewController("/").setViewName(this.rootControllerViewName);
        }
        
        List<Locale> locale = Collections.singletonList(new Locale("en"));

    	@Override
    	public Locale resolveLocale(HttpServletRequest request) {
    		String headerLang = request.getHeader("Accept-Language");
    		return headerLang == null || headerLang.isEmpty() ? Locale.getDefault()
    				: Locale.lookup(Locale.LanguageRange.parse(headerLang), locale);
    	}

    	@Bean
    	public ResourceBundleMessageSource messageSource() {
    		ResourceBundleMessageSource rs = new ResourceBundleMessageSource();
    		rs.setBasename("messages");
    		rs.setDefaultEncoding("UTF-8");
    		rs.setUseCodeAsDefaultMessage(true);
    		return rs;
    	}
    	
    }

}

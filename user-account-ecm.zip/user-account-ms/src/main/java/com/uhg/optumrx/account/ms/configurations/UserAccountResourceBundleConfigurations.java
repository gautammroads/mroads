package com.uhg.optumrx.account.ms.configurations;

import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.lang.NonNull;
import com.uhg.optumrx.account.ms.helper.Translator;
import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;

@UtilityClass
public class UserAccountResourceBundleConfigurations {

	@Configuration
	@AutoConfigureAfter({ UserAccountWebMvcConfigurers.class })
	@Value
	@NonFinal
	@Accessors(fluent = true)
	public static class UserAccountResourceBundleConfiguration {

		@NonNull
		final ResourceBundleMessageSource messageSource;

		@Bean
		@ConditionalOnMissingBean
		public Translator translator() {
			return new Translator(messageSource());
		}

	}

}

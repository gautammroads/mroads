package com.uhg.optumrx.account.ms.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;


@UtilityClass
public class UserAccountRestTemplateConfigrations {

	@Configuration
	@Value
	@NonFinal
	@Accessors(fluent = true)
	public static class UserAccountRestTemplateConfigration {

		@Bean
		public RestTemplate restTemplate() {
		    return new RestTemplate();
		}
	}
}

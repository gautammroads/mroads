package com.uhg.optumrx.account.ms.helper;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class UserAccountUtility {
	
	
	
	private UserAccountUtility() {
		
	}

	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

	public static String getUUID() {
		MessageDigest salt = null;
		String uuid = UUID.randomUUID().toString();
		try {
			salt = MessageDigest.getInstance("SHA-256");
			salt.update(uuid.getBytes(Charset.defaultCharset()));
		} catch (NoSuchAlgorithmException e) {
			LOGGER.trace("getUUID(NoSuchAlgorithmException: {})", e.getMessage());
		}
		if (salt != null)
			uuid = bytesToHex(salt.digest());
		return uuid;
	}

	private static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = HEX_ARRAY[v >>> 4];
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars);
	}
	
	@SafeVarargs
	public static <T> Predicate<T> distinctByKeys(Function<? super T, ?>... keyExtractors) {
		final Map<List<?>, Boolean> seen = new ConcurrentHashMap<>();

		return t -> {
			final List<?> keys = Arrays.stream(keyExtractors).map(ke -> ke.apply(t)).collect(Collectors.toList());

			return seen.putIfAbsent(keys, Boolean.TRUE) == null;
		};
	}

}

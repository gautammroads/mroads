package com.uhg.optumrx.account.ms.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.web.client.RestTemplate;
import com.optum.orcn.user.account.cosmos.Close;
import com.optum.orcn.user.account.cosmos.Coordinates;
import com.optum.orcn.user.account.cosmos.DeleteCouponRequest;
import com.optum.orcn.user.account.cosmos.Device;
import com.optum.orcn.user.account.cosmos.DrugCoupons;
import com.optum.orcn.user.account.cosmos.FavoriteLocation;
import com.optum.orcn.user.account.cosmos.FavoriteLocationPreference;
import com.optum.orcn.user.account.cosmos.ImageWithDarkModeSupport;
import com.optum.orcn.user.account.cosmos.Notification;
import com.optum.orcn.user.account.cosmos.NotificationPreference;
import com.optum.orcn.user.account.cosmos.Open;
import com.optum.orcn.user.account.cosmos.OperatingHours;
import com.optum.orcn.user.account.cosmos.PreferenceResponse;
import com.optum.orcn.user.account.cosmos.Preferences;
import com.optum.orcn.user.account.cosmos.Retailer;
import com.optum.orcn.user.account.cosmos.RetailerLocation;
import com.optum.orcn.user.account.cosmos.UpdateCouponRequest;
import com.optum.orcn.user.account.cosmos.UpdateDeviceRequest;
import com.optum.orcn.user.account.cosmos.UpdatePreferenceRequest;
import com.optum.orcn.user.account.cosmos.UserAccountCouponsSearchByNdcRequest;
import com.optum.orcn.user.account.cosmos.UserSearchByIdRequest;
import com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption.PharmacyAddress;
import com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption.PharmacyCommunication;
import com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption.PharmacyInformation;
import com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption.RetailPharmacyLocation;
import com.uhg.optumrx.account.ms.UserAccountMsApplicationProperties;
import com.uhg.optumrx.account.ms.entity.Metadata;
import com.uhg.optumrx.account.ms.entity.PharmacyInformationResponse;
import com.uhg.optumrx.account.ms.entity.PharmacyPost;
import com.uhg.optumrx.account.ms.entity.UserAccountEntity;
import com.uhg.optumrx.account.ms.exception.NoSuchCouponFoundException;
import com.uhg.optumrx.account.ms.exception.NoSuchDrugNdcFoundForAccountIDException;
import com.uhg.optumrx.account.ms.exception.NoSuchRecordFoundException;
import com.uhg.optumrx.account.ms.helper.UserAccountUtility;
import com.uhg.optumrx.account.ms.repository.UserAccountCosmosRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;
import lombok.extern.log4j.Log4j2;

@UtilityClass
public class UserAccountServices {

	public interface UserAccountService {

		UserAccountEntity saveAccount(UserAccountEntity entity);

		Optional<UserAccountEntity> getAccount(String accountId);

		UserAccountEntity updateDevices(UpdateDeviceRequest request);

		PreferenceResponse updatePreferences(String authorization, UpdatePreferenceRequest request);

		UserAccountEntity saveOrUpdateCoupons(UpdateCouponRequest request);

		List<String> getCouponsForDrugndc(UserAccountCouponsSearchByNdcRequest request);

		List<Device> getEntityWithUpdatedDevices(List<Device> reqDeviceList, List<Device> resDeviceList);

		Preferences getEntityWithUpdatedPreferences(Preferences preferencesRequest, Preferences preferencesResponse);

		UserAccountEntity updateUserAccount(@NonNull final UserAccountEntity reqEntity);

		UserAccountEntity createUserAccount();

		PreferenceResponse searchPreferences(String authorization, UserSearchByIdRequest request);

		void deleteCoupons(DeleteCouponRequest request);

		List<DrugCoupons> getAssociatedDrugCoupons(UserSearchByIdRequest request);

	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@NonFinal
	@Accessors(fluent = true)
	@Log4j2
	public static class UserAccountServiceImpl implements UserAccountService {

		UserAccountCosmosRepository accountCosmosRepository;
		RestTemplate restTemplate;
		UserAccountMsApplicationProperties userAccountMsApplicationProperties;

		@Override
		public UserAccountEntity saveAccount(UserAccountEntity entity) {
			LOGGER.info("UserAccountServiceImpl: inside saveAccount(entity:{})", entity);
			final var userAccountEntity = accountCosmosRepository.save(entity);
			LOGGER.info("UserAccountServiceImpl: outside saveAccount(request:{}) response: {}", entity,
					userAccountEntity);
			return userAccountEntity;

		}

		@Override
		public Optional<UserAccountEntity> getAccount(String accountId) {
			LOGGER.info("UserAccountServiceImpl: inside getAccount(accountId:{})", accountId);
			final var userAccountEntity = accountCosmosRepository.findById(accountId);
			LOGGER.info("UserAccountServiceImpl: outside getAccount(request:{}) response: {}", accountId,
					userAccountEntity);
			return userAccountEntity;
		}

		@Override
		public UserAccountEntity updateDevices(final UpdateDeviceRequest request) {
			LOGGER.info("UserAccountServiceImpl: inside updateDevice(request:{})", request);
			String accountId = request.getAccountId();
			final var userAccountEntity = accountCosmosRepository.findById(accountId).map(entity -> {
				entity.setDevices(getEntityWithUpdatedDevices(request.getDevices(), entity.getDevices()));
				return accountCosmosRepository.save(entity);
			}).orElseThrow(NoSuchRecordFoundException::new);
			LOGGER.info("UserAccountServiceImpl: outside updateDevice(request:{}) response: {}", request,
					userAccountEntity);
			return userAccountEntity;
		}

		public List<Device> getEntityWithUpdatedDevices(List<Device> reqDeviceList, List<Device> resDeviceList) {
			LOGGER.info("UserAccountServiceImpl: inside getEntityWithUpdatedDevices() method");
			List<Device> deviceList = Optional.ofNullable(resDeviceList).orElseGet(Collections::emptyList);
			List<Device> requestDeviceList = Optional.ofNullable(reqDeviceList).orElseGet(Collections::emptyList);
			List<Device> list = Stream.concat(requestDeviceList.stream(), deviceList.stream())
					.collect(Collectors.toList());
			LOGGER.info("UserAccountServiceImpl: out getEntityWithUpdatedDevices() method");
			return distinctByKeysAndSetDeviceId(list);
		}

		@Override
		public PreferenceResponse updatePreferences(String authorization, UpdatePreferenceRequest request) {
			LOGGER.info("UserAccountServiceImpl: inside updatePreferences method (request{})", request);

			return accountCosmosRepository.findById(request.getAccountId()).map(entity -> {
				Preferences preferences = getEntityWithUpdatedPreferences(request.getPreferences(),
						entity.getPreferences());
				entity.setPreferences(preferences);
				accountCosmosRepository.save(entity);
				Collection<FavoriteLocation> favoriteLocation = preferences.getFavoriteLocations()
						.orElseGet(Collections::emptyList);
				Collection<Notification> notifications = preferences.getNotifications()
						.orElseGet(Collections::emptyList);
				PreferenceResponse preferenceResponse = convertPharmacyInformationToPreferenceResponse(
						pharmacyServicecall(authorization, favoriteLocation), favoriteLocation);
				preferenceResponse.setNotifications(notificationConverter(notifications));
				LOGGER.info("UserAccountServiceImpl: inside updatePreferences method (response{})", preferenceResponse);
				return preferenceResponse;
			}).orElseThrow(NoSuchRecordFoundException::new);
		}

		public Preferences getEntityWithUpdatedPreferences(Preferences preferencesRequest,
				Preferences preferencesResponse) {
			LOGGER.info("UserAccountServiceImpl: Inside getEntityWithUpdatedPreferences()");
			Preferences entityPreferences = Optional.ofNullable(preferencesResponse).orElseGet(Preferences::new);
			List<FavoriteLocation> requestFavoriteLocationList = preferencesRequest.getFavoriteLocations()
					.orElseGet(Collections::emptyList);
			List<FavoriteLocation> mfavoriteLocation = new ArrayList<>();
			requestFavoriteLocationList.stream().forEach(mapper -> {
				if (!mapper.getFavLocationId().isPresent())
					mapper.setFavLocationId(UserAccountUtility.getUUID());
				mfavoriteLocation.add(mapper);
			});
			List<FavoriteLocation> entityFavoriteLocationList = entityPreferences.getFavoriteLocations()
					.orElseGet(Collections::emptyList);
			List<Notification> requestNotificationsList = preferencesRequest.getNotifications()
					.orElseGet(Collections::emptyList);
			List<Notification> entityNotificationsList = entityPreferences.getNotifications()
					.orElseGet(Collections::emptyList);
			List<FavoriteLocation> favouriteLocations = Stream
					.concat(mfavoriteLocation.stream(), entityFavoriteLocationList.stream())
					.filter(UserAccountUtility.distinctByKeys(FavoriteLocation::getRetailerLocationId))
					.collect(Collectors.toList());
			List<Notification> notifications = Stream
					.concat(requestNotificationsList.stream(), entityNotificationsList.stream())
					.filter(UserAccountUtility.distinctByKeys(Notification::getNotificationId))
					.collect(Collectors.toList());
			LOGGER.info("UserAccountServiceImpl: Outside getEntityWithUpdatedPreferences()");
			return new Preferences(favouriteLocations, notifications);
		}

		public UserAccountEntity updateUserAccount(@NonNull final UserAccountEntity reqEntity) {
			LOGGER.info("UserAccountServiceImpl: inside updateUserAccount(reqEntity:{})", reqEntity);
			final var userAccountEntity = Optional.ofNullable(reqEntity.getAccountId()).isPresent()
					? getAccount(reqEntity.getAccountId()).map(resEntity -> {
						resEntity.setContactInfo(reqEntity.getContactInfo());
						resEntity.setGlobalMembershipInfo(reqEntity.getGlobalMembershipInfo());
						resEntity.setOptumMembershipInfo(reqEntity.getOptumMembershipInfo());
						resEntity.setIsAccountActive(reqEntity.getIsAccountActive());
						resEntity.setCommunicationPreferences(reqEntity.getCommunicationPreferences());
						reqEntity.setDevices(
								getEntityWithUpdatedDevices(reqEntity.getDevices(), resEntity.getDevices()));
						reqEntity.setPreferences(getEntityWithUpdatedPreferences(reqEntity.getPreferences(),
								resEntity.getPreferences()));

						return saveAccount(resEntity);
					}).orElseGet(() -> this.createUserAccount())
					: this.createUserAccount();
			LOGGER.info("UserAccountServiceImpl: out updateUserAccount(request:{}) response: {}", reqEntity,
					userAccountEntity);
			return userAccountEntity;
		}

		public UserAccountEntity createUserAccount() {
			LOGGER.info("UserAccountServiceImpl: inside createUserAccount() method");
			final var userAccountEntity = saveAccount(new UserAccountEntity(UserAccountUtility.getUUID()));
			LOGGER.info("UserAccountServiceImpl: outside createUserAccount() response: {}", userAccountEntity);
			return userAccountEntity;
		}

		@Override
		public PreferenceResponse searchPreferences(String authorization, UserSearchByIdRequest request) {
			LOGGER.info("UserAccountServiceImpl: Inside searchPreferences() method(request{})", request);
			return accountCosmosRepository.findById(request.getAccountId()).map(entity -> {

				Preferences preferences = Optional.ofNullable(entity).map(UserAccountEntity::getPreferences)
						.orElseGet(Preferences::new);
				Collection<FavoriteLocation> favoriteLocations = preferences.getFavoriteLocations()
						.orElseGet(Collections::emptyList);
				PreferenceResponse preferenceResponse = convertPharmacyInformationToPreferenceResponse(
						pharmacyServicecall(authorization, favoriteLocations), favoriteLocations);
				preferenceResponse.setNotifications(
						notificationConverter(preferences.getNotifications().orElseGet(Collections::emptyList)));
				LOGGER.info("UserAccountServiceImpl: Inside searchPreferences() method(response{})",
						preferenceResponse);
				return preferenceResponse;
			}).orElseThrow(NoSuchRecordFoundException::new);
		}

		private Collection<PharmacyInformation> pharmacyServicecall(String authorization,
				Collection<FavoriteLocation> favoriteLocation) {
			LOGGER.info("UserAccountServiceImpl: Inside pharmacyServicecall- calling Pharmacy service");
			List<Optional<String>> favoriteLocationList = favoriteLocation.stream()
					.map(FavoriteLocation::getRetailerLocationId).collect(Collectors.toList());
			List<String> locationIdList = favoriteLocationList.stream().flatMap(Optional::stream)
					.collect(Collectors.toList());
			PharmacyPost pharmacyPost = new PharmacyPost();
			pharmacyPost.setData(locationIdList);
			pharmacyPost.setMetadata(new Metadata());
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", authorization);
			HttpEntity<PharmacyPost> request = new HttpEntity<>(pharmacyPost, headers);
			PharmacyInformationResponse pharmacyInformationResponse = restTemplate.postForObject(
					userAccountMsApplicationProperties.getRetailPharmacyLocationSearchUrl(), request,
					PharmacyInformationResponse.class);
			LOGGER.info("UserAccountServiceImpl:Out pharmacyServicecall- calling Pharmacy service end");
			return Optional.ofNullable(pharmacyInformationResponse).map(PharmacyInformationResponse::getData)
					.orElseThrow(NoSuchRecordFoundException::new);

		}

		private PreferenceResponse convertPharmacyInformationToPreferenceResponse(
				Collection<PharmacyInformation> pharmacyInformations, Collection<FavoriteLocation> favoriteLocation) {
			PreferenceResponse preferenceResponse = new PreferenceResponse();
			final List<FavoriteLocationPreference> favoriteLocationPreferences = new ArrayList<>();
			LOGGER.debug("UserAccountServiceImpl: Inside convertPharmacyInformationToPreferenceResponse(request{})",
					pharmacyInformations);
			pharmacyInformations.stream().forEach(pharmacy -> {

				final Retailer retailer = new Retailer();
				pharmacy.getRetailer().ifPresent(pharmacyRetailer -> {
					retailer.setId(pharmacyRetailer.getAffiliationId());
					retailer.setIsMembershipRequired(pharmacyRetailer.isMembershipRequired());
					retailer.setMembershipDetailsUrl(String.valueOf(pharmacyRetailer.getMembershipDetailsUrl().get()));
					retailer.setName(pharmacyRetailer.getAffiliationName());
					ImageWithDarkModeSupport imageWithDarkModeSupport = new ImageWithDarkModeSupport();
					imageWithDarkModeSupport.setImageUrl(String.valueOf(pharmacyRetailer.getLogoImageUrl().get()));
					imageWithDarkModeSupport
							.setDarkModeImageUrl(String.valueOf(pharmacyRetailer.getDarkModeImageUrl().get()));
					retailer.setLogo(imageWithDarkModeSupport);
				});
				FavoriteLocationPreference favoriteLocationPreference = new FavoriteLocationPreference();
				favoriteLocation.forEach(action -> {
					if (pharmacy.getPharmacyId().equals(action.getRetailerLocationId().get()))
						favoriteLocationPreference.setId(action.getFavLocationId().orElseGet(String::new));
				});
				favoriteLocationPreference.setRetailer(retailer);
				favoriteLocationPreference.setLocation(locationConverter(pharmacy.getLocation()));
				favoriteLocationPreferences.add(favoriteLocationPreference);
				preferenceResponse.setFavoriteLocations(favoriteLocationPreferences);
			});

			LOGGER.debug("UserAccountServiceImpl: Out convertPharmacyInformationToPreferenceResponse(response{})",
					preferenceResponse);
			return preferenceResponse;

		}

		private RetailerLocation locationConverter(Optional<RetailPharmacyLocation> locations) {
			final RetailerLocation retailerLocation = new RetailerLocation();
			final Coordinates coordinates = new Coordinates();
			LOGGER.info("UserAccountServiceImpl: Inside locationConverter method (request{})", locations);
			locations.stream().forEach(pharmacyLocation -> {
				retailerLocation.setId(pharmacyLocation.getPharmacyId());
				PharmacyAddress pharmacyAddress = pharmacyLocation.getPharmacyAddress().orElseGet(PharmacyAddress::new);
				retailerLocation.setAddressLine1(pharmacyAddress.getAddressLine1());
				retailerLocation.setAddressLine2(pharmacyAddress.getAddressLine2().orElseGet(String::new));
				retailerLocation.setCity(pharmacyAddress.getCity().orElseGet(String::new));
				retailerLocation.setState(pharmacyAddress.getState().orElseGet(String::new));
				retailerLocation.setZipCode(pharmacyAddress.getPostalCode());
				retailerLocation.setState(pharmacyAddress.getState().orElseGet(String::new));
				coordinates.setLatitude(pharmacyAddress.getLatitudeDegree());
				coordinates.setLongitude(pharmacyAddress.getLongitudeDegree());
				retailerLocation.setCoordinates(coordinates);
				PharmacyCommunication pharmacyCommunication = pharmacyLocation.getPharmacyCommunication()
						.orElseGet(PharmacyCommunication::new);

				retailerLocation.setHours(operstingTimeConveter(pharmacyLocation.getPharmacySchedule()));
				retailerLocation.setPhoneNumber(pharmacyCommunication.getTelephoneNumber());
			});
			LOGGER.info("UserAccountServiceImpl: outside locationConverter method (response{})", retailerLocation);
			return retailerLocation;
		}

		private List<OperatingHours> operstingTimeConveter(
				Optional<List<com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption.OperatingHours>> optional) {
			final List<OperatingHours> operatingHoursList = new ArrayList<>();
			LOGGER.info("UserAccountServiceImpl: Inside operstingTimeConveter method ()");
			Collection<com.optum.rx.orcn.pharmacy.ecm.v1.retail.location.consumption.OperatingHours> operating = optional
					.isPresent() ? optional.get() : Collections.emptyList();
			operating.stream().forEach(hours -> {
				Open open = new Open();
				Close close = new Close();
				OperatingHours operatingTime = new OperatingHours();
				open.setTime(hours.getOpeningTime());
				close.setTime(hours.getClosingTime());
				open.setDay(hours.getDayOfWeek().name());
				operatingTime.setOpen(open);
				operatingTime.setClose(close);
				operatingHoursList.add(operatingTime);
			});
			LOGGER.info("UserAccountServiceImpl: outside operstingTimeConveter method ()");
			return operatingHoursList;

		}

		private List<NotificationPreference> notificationConverter(Collection<Notification> notifications) {
			LOGGER.info("UserAccountServiceImpl: inside notificationConverter method ()");
			final List<NotificationPreference> notificationPreferences = new ArrayList<>();
			notifications.stream().forEach(notification -> {
				NotificationPreference notificationPreference = new NotificationPreference();
				notificationPreference.setId(notification.getNotificationId().orElseGet(String::new));

				notificationPreference.setEnabled(notification.getEnabled().isPresent());
				notificationPreference.setType(NotificationPreference.Type.DRUG_NEWS);
				notificationPreferences.add(notificationPreference);
			});
			LOGGER.info("UserAccountServiceImpl: outside notificationConverter method ()");
			return notificationPreferences;
		}

		@Override
		public UserAccountEntity saveOrUpdateCoupons(final UpdateCouponRequest request) {
			LOGGER.info("UserAccountServiceImpl: inside saveOrUpdateCoupons(request:{})", request);
			final var userAccountEntity = accountCosmosRepository.findById(request.getAccountId()).map(entity -> {
				List<DrugCoupons> reqcouponsList = Optional.ofNullable(request.getSavedDrugCoupons())
						.orElseGet(Collections::emptyList);
				List<DrugCoupons> rescouponsList = Optional.ofNullable(entity.getSavedDrugCoupons())
						.orElseGet(Collections::emptyList);
				entity.setSavedDrugCoupons(distinctByNdcAndSetCoupons(
						Stream.concat(reqcouponsList.stream(), rescouponsList.stream()).collect(Collectors.toList())));
				return accountCosmosRepository.save(entity);
			}).orElseThrow(NoSuchRecordFoundException::new);
			LOGGER.info("UserAccountServiceImpl: outside saveOrUpdateCoupons(request:{}) response: {}", request,
					userAccountEntity);
			return userAccountEntity;
		}

		@Override
		public List<String> getCouponsForDrugndc(UserAccountCouponsSearchByNdcRequest request) {
			LOGGER.info("UserAccountServiceImpl: inside getCouponsForDrugndc(request:{})", request);
			final var drugCouponsList = accountCosmosRepository.findById(request.getAccountId()).map(entity -> {
				List<DrugCoupons> resdrugCoupons = Optional.ofNullable(entity.getSavedDrugCoupons())
						.orElseGet(Collections::emptyList);
				return resdrugCoupons.stream()
						.filter(drugCoupon -> request.getDrugNdc().equals(drugCoupon.getDrugNdc())).map(e -> {
							if (e.getSavedCoupons().get().size() == 0)
								throw new NoSuchCouponFoundException();
							return e.getSavedCoupons().get();
						}).findFirst().orElseThrow(NoSuchDrugNdcFoundForAccountIDException::new);
			}).orElseThrow(NoSuchRecordFoundException::new);
			LOGGER.info("UserAccountServiceImpl: outside getCouponsForDrugndc(request:{}) response: {}", request,
					drugCouponsList);
			return drugCouponsList;
		}

		@Override
		public void deleteCoupons(DeleteCouponRequest request) {
			LOGGER.info("UserAccountServiceImpl:Inside deleteCoupons(request:{})", request);
			accountCosmosRepository.findById(request.getAccountId()).ifPresentOrElse(entity -> {
				List<DrugCoupons> drugCoupons = Optional.ofNullable(entity.getSavedDrugCoupons())
						.orElseGet(Collections::emptyList);
				drugCoupons.stream()
						.forEach(coupon -> coupon.setSavedCoupons(coupon.getSavedCoupons()
								.filter(predicate -> predicate.removeIf(filter -> filter.equals(request.getCouponId())))
								.orElseGet(Collections::emptyList)));
				entity.setSavedDrugCoupons(drugCoupons);
				accountCosmosRepository.save(entity);
				LOGGER.info("UserAccountServiceImpl:outside deleteCoupons(response{})", entity);
			}, () -> {
				throw new NoSuchCouponFoundException();
			});
			LOGGER.info("UserAccountServiceImpl:outside deleteCoupons()");
		}
		
		@Override
		public List<DrugCoupons> getAssociatedDrugCoupons(UserSearchByIdRequest request) {
			LOGGER.info("UserAccountServiceImpl: inside getAssociatedDrugCoupons(request:{})", request);
			final var drugCoupons = accountCosmosRepository.findById(request.getAccountId()).map(entity -> {
				List<DrugCoupons> drugCouponsList = entity.getSavedDrugCoupons();
				return Optional.ofNullable(drugCouponsList).orElseThrow(NoSuchCouponFoundException::new);
			}).orElseThrow(NoSuchRecordFoundException::new);
			LOGGER.info("UserAccountServiceImpl: outside getAssociatedDrugCoupons(request:{}) response: {}",
					drugCoupons);
			return drugCoupons;
		}

		private List<Device> distinctByKeysAndSetDeviceId(Collection<Device> devices) {
			final Map<String, Device> seen = new ConcurrentHashMap<>();
			devices.stream().forEach(device -> {
				String key = device.getDeviceIdentifier();
				if (seen.putIfAbsent(key, device) == null)
					seen.get(key).setDeviceId(UserAccountUtility.getUUID());
				seen.get(key).setDeviceId(device.getDeviceId().get());
			});
			return new ArrayList<>(seen.values());
		}

		private List<DrugCoupons> distinctByNdcAndSetCoupons(Collection<DrugCoupons> drugCoupons) {
			final Map<String, DrugCoupons> seen = new ConcurrentHashMap<>();
			drugCoupons.stream().forEach(drugCoupon -> {
				String key = drugCoupon.getDrugNdc();
				if (Optional.ofNullable(seen.putIfAbsent(key, drugCoupon)).isPresent()) {
					List<String> reqcouponsList = seen.get(key).getSavedCoupons().orElseGet(Collections::emptyList);
					List<String> rescouponsList = drugCoupon.getSavedCoupons().orElseGet(Collections::emptyList);
					seen.get(key).setSavedCoupons(Stream.concat(reqcouponsList.stream(), rescouponsList.stream())
							.distinct().collect(Collectors.toList()));
				}
			});
			return new ArrayList<>(seen.values());
		}
	}

}

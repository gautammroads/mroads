package com.uhg.optumrx.account.ms.configurations;

import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import com.uhg.optumrx.account.ms.configurations.UserAccountServiceAutoConfigurations.UserAccountServiceAutoConfiguration;
import com.uhg.optumrx.account.ms.controller.UserAccountController;
import com.uhg.optumrx.account.ms.controller.UserAccountController.UserAccountControllerImpl;
import com.uhg.optumrx.account.ms.services.UserAccountServices.UserAccountService;
import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;


@UtilityClass
public class UserAccountControllerAutoConfigurations {

    @Configuration
    @AutoConfigureAfter(UserAccountServiceAutoConfiguration.class)
    @Value
    @NonFinal
    @Accessors(fluent = true)
    public static class UserAccountControllerAutoConfiguration {

        @NonNull
        final UserAccountService userAcccountService;

        @Bean
        public UserAccountController userAccountController() {
            return new UserAccountControllerImpl(userAcccountService);
        }

    }
}

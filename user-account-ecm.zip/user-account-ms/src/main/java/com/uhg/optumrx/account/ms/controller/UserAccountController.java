package com.uhg.optumrx.account.ms.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.optum.orcn.user.account.cosmos.DeleteCouponRequest;
import com.optum.orcn.user.account.cosmos.DrugCoupons;
import com.optum.orcn.user.account.cosmos.PreferenceResponse;
import com.optum.orcn.user.account.cosmos.UpdateCouponRequest;
import com.optum.orcn.user.account.cosmos.UpdateDeviceRequest;
import com.optum.orcn.user.account.cosmos.UpdatePreferenceRequest;
import com.optum.orcn.user.account.cosmos.UserAccountCouponsSearchByNdcRequest;
import com.optum.orcn.user.account.cosmos.UserSearchByIdRequest;
import com.uhg.optumrx.account.ms.entity.UserAccountEntity;
import com.uhg.optumrx.account.ms.exception.NoSuchRecordFoundException;
import com.uhg.optumrx.account.ms.services.UserAccountServices.UserAccountService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.extern.log4j.Log4j2;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-08-28T15:00:40.978Z[GMT]")
@RestController
@RequestMapping("/user/account")
public interface UserAccountController {

	@Operation
	@PostMapping(path = "/v1.0", produces = APPLICATION_JSON_VALUE)
	ResponseEntity<UserAccountEntity> saveOrUpdateAccount(@RequestBody Optional<UserAccountEntity> request);

	@Operation
	@PostMapping(path = "/v1.0/searchById", produces = APPLICATION_JSON_VALUE)
	ResponseEntity<UserAccountEntity> getUserAccount(
			@Valid @RequestBody(required = true) UserSearchByIdRequest request);

	@Operation
	@PostMapping(path = "/device/v1.0", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
	ResponseEntity<UserAccountEntity> updateDevices(
			@Valid @RequestBody(required = true) UpdateDeviceRequest updateDeviceRequest);

	@Operation
	@PostMapping(path = "/preferences/v1.0", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
	ResponseEntity<PreferenceResponse> updatePreferences(@RequestHeader(value = "Authorization") String authorization,
			@Valid @RequestBody(required = true) UpdatePreferenceRequest request);

	@Operation
	@PostMapping(path = "/preferences/v1.0/searchById", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
	ResponseEntity<PreferenceResponse> searchPreferences(@RequestHeader(value = "Authorization") String authorization,
			@Valid @RequestBody(required = true) UserSearchByIdRequest request);

	@Operation
	@PostMapping(path = "/coupons/v1.0", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
	ResponseEntity<UserAccountEntity> saveOrUpdateCoupons(
			@Valid @RequestBody(required = true) UpdateCouponRequest request);

	@Operation
	@PostMapping(path = "/coupons/v1.0/searchByNdc", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
	ResponseEntity<List<String>> getCouponsForDrugndc(
			@Valid @RequestBody(required = true) UserAccountCouponsSearchByNdcRequest request);

	@Operation
	@PostMapping(path = "/coupons/v1.0/deleteCoupon", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	void deleteCoupon(@Valid @RequestBody(required = true) DeleteCouponRequest request);

	@Operation
	@PostMapping(path = "/coupons/v1.0/searchByAccountId", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
	ResponseEntity<List<DrugCoupons>> getAssociatedDrugCoupons(
			@Valid @RequestBody(required = true) UserSearchByIdRequest request);

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@NonFinal
	@Accessors(fluent = true)
	@Log4j2
	public static class UserAccountControllerImpl implements UserAccountController {

		UserAccountService userAccountService;

		@Override
		public ResponseEntity<UserAccountEntity> saveOrUpdateAccount(final Optional<UserAccountEntity> request) {
			LOGGER.info("In UserAccountControllerImpl: saveOrUpdateAccount(request:{})", request);
			final var response = ResponseEntity.ok(request.map(userAccountService::updateUserAccount)
					.orElseGet(userAccountService::createUserAccount));
			LOGGER.info("Out UserAccountControllerImpl: saveOrUpdateAccount(request:{}) response:{}", request,
					response);
			return response;
		}

		@Override
		public ResponseEntity<UserAccountEntity> getUserAccount(final UserSearchByIdRequest request) {
			LOGGER.info("In UserAccountControllerImpl: getUserAccount(request:{})", request);
			final var response = userAccountService.getAccount(request.getAccountId())
					.map(entity -> ResponseEntity.ok(entity)).orElseThrow(NoSuchRecordFoundException::new);
			LOGGER.info("Out UserAccountControllerImpl: getUserAccount(request:{}) response:{}", request, response);
			return response;
		}

		@Override
		public ResponseEntity<UserAccountEntity> updateDevices(final UpdateDeviceRequest request) {
			LOGGER.info("In UserAccountControllerImpl: updateDevice(request:{})", request);
			final var response = userAccountService.getAccount(request.getAccountId())
					.map(entity -> ResponseEntity.ok(userAccountService.updateDevices(request)))
					.orElseThrow(NoSuchRecordFoundException::new);
			LOGGER.info("Out UserAccountControllerImpl: updateDevice(request:{}) response:{}", request, response);
			return response;
		}

		@Override
		public ResponseEntity<PreferenceResponse> updatePreferences(String authorization,
				UpdatePreferenceRequest request) {
			LOGGER.info("In UserAccountControllerImpl: updatePreferences(request:{})", request);
			final var response = ResponseEntity.status(HttpStatus.OK)
					.body(userAccountService.updatePreferences(authorization, request));
			LOGGER.info("Out UserAccountControllerImpl: updatePreferences(request:{}) response:{}", request, response);
			return response;

		}

		@Override
		public ResponseEntity<PreferenceResponse> searchPreferences(String authorization,
				UserSearchByIdRequest request) {
			LOGGER.info("In UserAccountControllerImpl: searchPreferences(request:{})", request);
			final var response = ResponseEntity.status(HttpStatus.OK)
					.body(userAccountService.searchPreferences(authorization, request));
			LOGGER.info("Out UserAccountControllerImpl: searchPreferences(request:{}) response:{}", request, response);
			return response;

		}

		@Override
		public ResponseEntity<UserAccountEntity> saveOrUpdateCoupons(final UpdateCouponRequest request) {
			LOGGER.info("In UserAccountControllerImpl: saveOrUpdateCoupons(request:{})", request);
			final var response = ResponseEntity.status(HttpStatus.OK)
					.body(userAccountService.saveOrUpdateCoupons(request));
			LOGGER.info("Out UserAccountControllerImpl: saveOrUpdateCoupons(request:{}) response:{}", request,
					response);
			return response;

		}

		@Override
		public ResponseEntity<List<String>> getCouponsForDrugndc(final UserAccountCouponsSearchByNdcRequest request) {
			LOGGER.info("In UserAccountControllerImpl: getCouponsForDrugndc(request:{})", request);
			final var response = ResponseEntity.status(HttpStatus.OK)
					.body(userAccountService.getCouponsForDrugndc(request));
			LOGGER.info("Out UserAccountControllerImpl: getCouponsForDrugndc(request:{}) response:{}", request,
					response);
			return response;
		}

		@Override
		public void deleteCoupon(final DeleteCouponRequest request) {
			LOGGER.info("In UserAccountControllerImpl: deleteCoupon(request:{})", request);
			userAccountService.deleteCoupons(request);
			LOGGER.info("Out UserAccountControllerImpl: deleteCoupon()");
		}

		@Override
		public ResponseEntity<List<DrugCoupons>> getAssociatedDrugCoupons(final UserSearchByIdRequest request) {
			LOGGER.info("In UserAccountControllerImpl: getAssociatedDrugCoupons(request:{})", request);
			final var response = ResponseEntity.status(HttpStatus.OK)
					.body(userAccountService.getAssociatedDrugCoupons(request));
			LOGGER.info("Out UserAccountControllerImpl: getAssociatedDrugCoupons(request:{}) response:{}", request,
					response);
			return response;
		}

	}
}

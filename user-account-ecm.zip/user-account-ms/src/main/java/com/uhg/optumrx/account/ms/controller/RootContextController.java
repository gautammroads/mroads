package com.uhg.optumrx.account.ms.controller;

import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;
import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;

@RestController
@Value
@NonFinal
@Accessors(fluent = true)
public class RootContextController {

	@NonNull
	final String rootRedirectViewUrl;

	/**
	 * Root.
	 *
	 * @return the redirect view
	 */
	@GetMapping("/")
	public RedirectView root() {
		return new RedirectView(this.rootRedirectViewUrl);
	}

}

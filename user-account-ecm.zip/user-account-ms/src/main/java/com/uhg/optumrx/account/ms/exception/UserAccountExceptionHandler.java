package com.uhg.optumrx.account.ms.exception;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.uhg.optumrx.account.ms.helper.Translator;

import lombok.AllArgsConstructor;
import lombok.Value;
import lombok.extern.log4j.Log4j2;

@Value
@Log4j2
@ControllerAdvice
@AllArgsConstructor
public class UserAccountExceptionHandler extends ResponseEntityExceptionHandler {

	final Translator translate;

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		LOGGER.info("UH-OH: CAUGHT EXCEPTION IN: " + Optional.ofNullable(ex.getCause())
				.map(e -> e.getStackTrace()[0].getMethodName()).orElse(ex.getMessage()));
		ex.printStackTrace();
		List<ErrorDetail> errors = new ArrayList<>();
		int[] counter = { 1 };
		ex.getBindingResult().getAllErrors().forEach(error -> {
			errors.add(new ErrorDetail(
					translate.toLocale("useraccount.errorcode.two") + String.format("%03d", counter[0]),
					((FieldError) error).getField(), translate.toLocale("word.the") + " "
							+ ((FieldError) error).getField() + " " + translate.toLocale("useraccount.message.two")));
			counter[0] = counter[0] + 1;
		});
		return new ResponseEntity<>(ExceptionResponse.builder().errors(errors).build(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<ErrorDetail> serverErrorExceptionHandler(Exception ex) {
		ex.printStackTrace();
		return new ResponseEntity<>(
				new ErrorDetail(translate.toLocale("useraccount.errorcode.one"),
						translate.toLocale("useraccount.title.one"), translate.toLocale("useraccount.message.one")),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ NoSuchRecordFoundException.class, NoSuchCouponFoundException.class,
			NoSuchDrugNdcFoundForAccountIDException.class })
	protected ResponseEntity<ErrorDetail> dataNotFoundExceptionHandler(Exception ex) {
		ex.printStackTrace();
		ErrorDetail errorDetail = null;
		if (ex instanceof NoSuchRecordFoundException) {
			errorDetail = new ErrorDetail(translate.toLocale("useraccount.errorcode.three"),
					translate.toLocale("useraccount.title.three"), translate.toLocale("useraccount.message.three"));
		} else if (ex instanceof NoSuchCouponFoundException) {
			errorDetail = new ErrorDetail(translate.toLocale("useraccount.couopn.errorcode.four"),
					translate.toLocale("useraccount.couopn.title.four"),
					translate.toLocale("useraccount.coupon.message.four"));
		} else if (ex instanceof NoSuchDrugNdcFoundForAccountIDException) {
			errorDetail = new ErrorDetail(translate.toLocale("useraccount.couopn.errorcode.five"),
					translate.toLocale("useraccount.couopn.title.five"),
					translate.toLocale("useraccount.coupon.message.five"));
		}
		return new ResponseEntity<>(errorDetail, HttpStatus.NOT_FOUND);

	}

}

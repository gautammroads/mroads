package com.uhg.optumrx.account.ms.configurations;

import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.client.RestTemplate;

import com.uhg.optumrx.account.ms.UserAccountMsApplicationProperties;
import com.uhg.optumrx.account.ms.configurations.UserAccountCosmosAutoConfigurations.UserAccountCosmosRepositoryAutoConfiguration;
import com.uhg.optumrx.account.ms.configurations.UserAccountRestTemplateConfigrations.UserAccountRestTemplateConfigration;
import com.uhg.optumrx.account.ms.repository.UserAccountCosmosRepository;
import com.uhg.optumrx.account.ms.services.UserAccountServices.UserAccountService;
import com.uhg.optumrx.account.ms.services.UserAccountServices.UserAccountServiceImpl;

import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;


@UtilityClass
public class UserAccountServiceAutoConfigurations {

    @Configuration
    @AutoConfigureAfter({ UserAccountCosmosRepositoryAutoConfiguration.class,UserAccountMsAutoConfigurations.class,UserAccountRestTemplateConfigration.class })
    @Value
    @NonFinal
    @Accessors(fluent = true)
    public static class UserAccountServiceAutoConfiguration {


        @NonNull
        final UserAccountCosmosRepository userAccountCosmosRepository; 
        
        @NonNull
        final RestTemplate restTemplate;
        
        
        @NonNull
        final UserAccountMsApplicationProperties userAccountMsApplicationProperties;
        
        
        @Bean
        @ConditionalOnMissingBean
    	public UserAccountService userAccountService() {
    		return new UserAccountServiceImpl(userAccountCosmosRepository,restTemplate ,userAccountMsApplicationProperties);
    		
    	}

    }
}

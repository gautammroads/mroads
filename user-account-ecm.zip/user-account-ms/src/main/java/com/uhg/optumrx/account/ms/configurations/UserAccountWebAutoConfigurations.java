package com.uhg.optumrx.account.ms.configurations;

import java.util.Optional;
import org.springdoc.core.SpringDocConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import com.uhg.optumrx.account.ms.UserAccountMsApplicationProperties;
import com.uhg.optumrx.account.ms.controller.RootContextController;

import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;

@UtilityClass
public class UserAccountWebAutoConfigurations {

    @AutoConfigureAfter({ SpringDocConfiguration.class, SpringDocConfiguration.class })
    @Configuration
    @Value
    @NonFinal
    @Accessors(fluent = true)
    public static class UserAccountWebMvcConfigurerAutoConfiguration {

        final UserAccountMsApplicationProperties userAccountMsApplicationProperties;


        @Bean
        public Optional<WebMvcConfigurer> userAccountWebMvcConfigurer() {
            return userAccountMsApplicationProperties().rootContextViewControllerViewName()
                    .map(UserAccountWebMvcConfigurers.RootContextWebMvcConfigurer::new);

        }
    }


    @AutoConfigureAfter({ SpringDocConfiguration.class, SpringDocConfiguration.class })
    @Configuration
    @Value
    @NonFinal
    @Accessors(fluent = true)
    public static class UserAccountRootControllerAutoConfiguration {

        final UserAccountMsApplicationProperties userAccountMsApplicationProperties;

        @Bean
        RootContextController rootContextController() {
            return new RootContextController(this.userAccountMsApplicationProperties.getRootRedirectViewUrl());

        }
    }
}

package com.uhg.optumrx.account.ms.entity;




import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * When page continuation token is provided, page and limit values are ignored
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "data",
    "metadata"
})
public class PharmacyPost {

    @JsonProperty("data")
    @Valid
    private List<String> data = new ArrayList<String>();
    @JsonProperty("metadata")
    @Valid
    private Metadata metadata;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public PharmacyPost() {
    }

    /**
     * 
     * @param metadata
     * @param data
     */
    public PharmacyPost(List<String> data, Metadata metadata) {
        super();
        this.data = data;
        this.metadata = metadata;
    }

    @JsonProperty("data")
    public Optional<List<String>> getData() {
        return Optional.ofNullable(data);
    }

    @JsonProperty("data")
    public void setData(List<String> data) {
        this.data = data;
    }

    @JsonProperty("metadata")
    public Optional<Metadata> getMetadata() {
        return Optional.ofNullable(metadata);
    }

    @JsonProperty("metadata")
    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

   
    
    

}

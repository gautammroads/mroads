package com.uhg.optumrx.account.ms.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseMetadata {
    private String respCode;
    private String respMessage[];
    private int recordCount;
    private int currentPage;
    private int totalRecordCount;
    private int totalPages;
    private String pageContinuationToken;
}

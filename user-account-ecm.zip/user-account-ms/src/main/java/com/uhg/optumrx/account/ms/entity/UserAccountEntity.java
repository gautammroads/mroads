package com.uhg.optumrx.account.ms.entity;

import java.util.List;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import com.optum.orcn.user.account.cosmos.AuditInfo;
import com.optum.orcn.user.account.cosmos.CommunicationPreference;
import com.optum.orcn.user.account.cosmos.ContactInfo;
import com.optum.orcn.user.account.cosmos.Device;
import com.optum.orcn.user.account.cosmos.DrugCoupons;
import com.optum.orcn.user.account.cosmos.GlobalMembershipInfo;
import com.optum.orcn.user.account.cosmos.OptumMembershipInfo;
import com.optum.orcn.user.account.cosmos.Preferences;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection = "user-account")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserAccountEntity {

	@Id
	@PartitionKey
	private String accountId;
	private OptumMembershipInfo optumMembershipInfo;
	private GlobalMembershipInfo globalMembershipInfo;
	private ContactInfo contactInfo;
	private CommunicationPreference communicationPreferences;
	private List<Device> devices;
	private List<DrugCoupons> savedDrugCoupons;
	private Preferences preferences;
	private String isAccountActive;
	private AuditInfo auditInfo;
	public UserAccountEntity(String accountId) {
		this.accountId = accountId;
	}
}

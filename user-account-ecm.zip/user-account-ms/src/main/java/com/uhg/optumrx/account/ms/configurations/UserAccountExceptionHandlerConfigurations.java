package com.uhg.optumrx.account.ms.configurations;

import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.uhg.optumrx.account.ms.exception.UserAccountExceptionHandler;
import com.uhg.optumrx.account.ms.helper.Translator;
import lombok.Value;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;
import lombok.experimental.UtilityClass;

@UtilityClass
public class UserAccountExceptionHandlerConfigurations {

	    @Configuration
	    @AutoConfigureAfter({ UserAccountResourceBundleConfigurations.class })
	    @Value
	    @NonFinal
	    @Accessors(fluent = true)
	    public static class UserAccountExceptionHandlerConfiguration {

	        final Translator translator;

	        @Bean
	    	public UserAccountExceptionHandler userAccountExceptionHandler() {
	    		return new UserAccountExceptionHandler(translator());
	    	}
	    }
}

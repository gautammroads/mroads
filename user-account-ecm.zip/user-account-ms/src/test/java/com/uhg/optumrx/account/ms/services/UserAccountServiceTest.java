package com.uhg.optumrx.account.ms.services;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.context.ConfigurationPropertiesAutoConfiguration;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestConstructor;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.TestConstructor.AutowireMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.optum.orcn.azure.spring.boot.cosmos.autoconfigure.CosmosAutoConfigurations.CosmosObjectMapperAutoConfiguration;
import com.uhg.optumrx.account.ms.entity.UserAccountEntity;
import lombok.experimental.Accessors;
import lombok.experimental.NonFinal;

@NonFinal
@Accessors(fluent = true)
@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
@TestConstructor(autowireMode = AutowireMode.ALL)
@TestPropertySource(properties = { "spring.main.banner-mode=off", "orcn.azure.cosmos.enabled=true" })
@SpringBootTest(webEnvironment = WebEnvironment.NONE)
@ImportAutoConfiguration({ ConfigurationPropertiesAutoConfiguration.class, JacksonAutoConfiguration.class,
		CosmosObjectMapperAutoConfiguration.class })
public class UserAccountServiceTest {


	@Autowired
	UserAccountServices.UserAccountService userAccountService;


	@Test
	void testCheckIfAccountCreated() {
		UserAccountEntity reqEntity= UserAccountEntity.builder().accountId("").build();
		final UserAccountEntity response = userAccountService.updateUserAccount(reqEntity);
		assertTrue(!response.getAccountId().isBlank());
	}
	
	@Test
	void testCheckIfAccountUpdated() {
		UserAccountEntity reqEntity= UserAccountEntity.builder().accountId("").build();
		UserAccountEntity response = userAccountService.updateUserAccount(reqEntity);
		assertTrue(!response.getAccountId().isBlank());
	}
	

	


}
